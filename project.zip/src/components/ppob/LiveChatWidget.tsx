"use client"
import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, Send, X, User, Loader2, ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { getLiveChatResponse, type LiveChatOutput } from '@/ai/flows/live-chat';
import Image from 'next/image';
import { useRouter } from 'next/navigation';

interface Message {
  role: 'admin' | 'user';
  text?: string;
  image?: string;
  time?: string;
}

export function LiveChatWidget() {
  const [mounted, setMounted] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'admin', text: 'Halo Kak! Saya asisten Abdi Pratama. Ada yang bisa saya bantu? Saya bisa membantu navigasi halaman, mencatat keuangan, atau mengecek transaksi Kakak!', time: '10:00' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  useEffect(() => { 
    setMounted(true); 
  }, []);

  useEffect(() => { 
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; 
  }, [messages, isOpen]);

  const executeCommand = (command: string) => {
    switch (command) {
      case 'NAV_RESELLER_REG':
        router.push('/signup');
        break;
      case 'NAV_RESELLER_DASHBOARD':
      case 'NAV_AFFILIATE_DASHBOARD':
      case 'NAV_WITHDRAW_AFFILIATE':
      case 'NAV_PROFILE':
        window.dispatchEvent(new CustomEvent('nav-view', { detail: 'DASHBOARD' }));
        break;
      case 'NAV_HISTORY':
        window.dispatchEvent(new CustomEvent('nav-view', { detail: 'STATUS' }));
        break;
      case 'NAV_DEPOSIT':
        window.dispatchEvent(new CustomEvent('nav-view', { detail: 'HOME' }));
        break;
      case 'LOGOUT':
        window.dispatchEvent(new CustomEvent('logout-action'));
        break;
    }
  };

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input;
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    setMessages(prev => [...prev, { role: 'user', text: userMessage, time }]);
    setInput('');
    setIsLoading(true);
    
    try {
      const response: LiveChatOutput = await getLiveChatResponse({ message: userMessage });
      
      setMessages(prev => [...prev, { 
        role: 'admin', 
        text: response.reply, 
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
      }]);

      if (response.command && response.command !== 'NONE') {
        executeCommand(response.command);
      }
    } catch (error) {
      setMessages(prev => [...prev, { 
        role: 'admin', 
        text: 'Maaf Kak, terjadi kendala teknis pada sistem asisten saya. Mohon tunggu sebentar atau coba lagi ya.', 
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64Image = event.target?.result as string;
        const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        setMessages(prev => [...prev, { role: 'user', image: base64Image, time }]);
        
        setTimeout(() => {
          setMessages(prev => [...prev, { 
            role: 'admin', 
            text: 'Terima kasih Kak, bukti fotonya sudah saya terima. Tunggu sebentar ya, saya cek dulu ke sistem.',
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
          }]);
        }, 1500);
      };
      reader.readAsDataURL(file);
    }
  };

  if (!mounted) return null;

  return (
    <div className="fixed bottom-24 right-6 z-[9999]">
      {isOpen ? (
        <div className="bg-white w-[350px] md:w-[400px] h-[600px] rounded-[3rem] shadow-2xl border border-slate-100 flex flex-col overflow-hidden animate-in slide-in-from-bottom-10 duration-300">
          <div className="bg-primary p-7 text-white flex justify-between items-center shadow-lg">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center border border-white/30 backdrop-blur-sm">
                <MessageSquare size={24} />
              </div>
              <div>
                <h4 className="font-black text-xs uppercase tracking-widest">Asisten AI</h4>
                <p className="text-[9px] opacity-80 font-bold flex items-center gap-1.5 mt-1">
                  <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" /> TERHUBUNG WEBSITE
                </p>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:bg-white/10 p-2 rounded-xl transition-all outline-none text-white"><X size={20} /></button>
          </div>

          <div ref={scrollRef} className="flex-1 p-6 overflow-y-auto space-y-4 no-scrollbar bg-slate-50/50">
            {messages.map((msg, i) => (
              <div key={i} className={cn("flex gap-2.5 max-w-[85%]", msg.role === 'user' ? "ml-auto flex-row-reverse" : "")}>
                <div className={cn("w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-[10px]", msg.role === 'admin' ? "bg-primary text-white" : "bg-slate-900 text-white")}>
                  <User size={12} />
                </div>
                <div className="flex flex-col gap-1">
                  <div className={cn(
                    "p-4 rounded-2xl text-[10px] font-bold leading-relaxed shadow-sm", 
                    msg.role === 'admin' ? "bg-white text-slate-700 rounded-tl-none border border-slate-100" : "bg-primary text-white rounded-tr-none"
                  )}>
                    {msg.image ? (
                      <div className="relative w-40 h-56 rounded-xl overflow-hidden mb-1">
                        <Image src={msg.image} alt="Upload" fill className="object-cover" />
                      </div>
                    ) : (
                      msg.text
                    )}
                  </div>
                  <span className={cn("text-[8px] font-bold text-slate-400 uppercase tracking-widest px-1", msg.role === 'user' ? "text-right" : "")}>{msg.time}</span>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-2.5 max-w-[80%]">
                <div className="w-7 h-7 rounded-full bg-primary text-white flex items-center justify-center"><User size={12} /></div>
                <div className="p-4 rounded-2xl bg-white border border-slate-100 shadow-sm flex items-center gap-2">
                  <Loader2 size={14} className="animate-spin text-primary" />
                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Memproses...</span>
                </div>
              </div>
            )}
          </div>

          <form onSubmit={handleSend} className="p-5 bg-white border-t border-slate-100 flex gap-2.5 items-center">
            <input 
              type="file" 
              accept="image/*" 
              ref={fileInputRef} 
              className="hidden" 
              onChange={handleImageUpload} 
            />
            <Button 
              type="button" 
              variant="ghost" 
              size="icon" 
              onClick={() => fileInputRef.current?.click()}
              className="rounded-xl h-12 w-12 shrink-0 text-slate-400 hover:text-primary hover:bg-primary/5 transition-all"
            >
              <ImageIcon size={20} />
            </Button>
            <Input 
              value={input} 
              onChange={(e) => setInput(e.target.value)} 
              placeholder="Coba: 'Buka riwayat transaksi'..." 
              className="rounded-2xl border-slate-200 h-12 text-[11px] font-bold text-slate-900 focus:ring-1" 
              disabled={isLoading} 
            />
            <Button 
              type="submit" 
              size="icon" 
              className="rounded-2xl h-12 w-12 shrink-0 shadow-xl shadow-primary/20 transition-transform active:scale-90" 
              disabled={isLoading || !input.trim()}
            >
              <Send size={18} />
            </Button>
          </form>
        </div>
      ) : (
        <button onClick={() => setIsOpen(true)} className="group relative flex items-center justify-center w-16 h-16 bg-slate-900 text-white rounded-[2rem] shadow-2xl hover:scale-110 active:scale-90 transition-all border-4 border-white focus:outline-none">
          <div className="absolute -top-12 right-0 bg-white text-slate-900 text-[9px] font-black px-4 py-2 rounded-xl shadow-2xl opacity-0 group-hover:opacity-100 transition-opacity uppercase tracking-widest whitespace-nowrap">AI Navigator</div>
          <MessageSquare size={28} />
          <span className="absolute inset-0 rounded-[2rem] bg-slate-900 animate-ping opacity-20" />
        </button>
      )}
    </div>
  );
}