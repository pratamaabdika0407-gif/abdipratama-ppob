
export function Footer() {
  return (
    <footer className="bg-zinc-950 text-slate-500 py-12 border-t border-white/5">
      <div className="container mx-auto px-4 text-center space-y-6">
        <p className="text-[10px] font-black uppercase tracking-[0.5em]">TERKONEKSI DENGAN VIP RESELLER SECURE GATEWAY</p>
        <div className="flex justify-center gap-8">
          <span className="text-xs font-bold">SYARAT & KETENTUAN</span>
          <span className="text-xs font-bold">KEBIJAKAN PRIVASI</span>
          <span className="text-xs font-bold">HUBUNGI KAMI</span>
        </div>
        <p className="text-[10px] font-bold opacity-30 italic">© 2025 GACOAN PPOB. ALL RIGHTS RESERVED. POWERED BY FIREBASE GENKIT.</p>
      </div>
    </footer>
  );
}
