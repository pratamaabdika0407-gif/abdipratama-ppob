
"use client"
import React, { useState } from 'react';
import { 
  Home, ClipboardList, User, Wallet, 
  ShieldCheck, LayoutDashboard,
  Sparkles, RefreshCcw, LogIn, UserPlus, Zap,
  TrendingUp
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';

interface BottomNavProps {
  currentView: 'HOME' | 'DASHBOARD' | 'STATUS';
  onViewChange: (view: 'HOME' | 'DASHBOARD' | 'STATUS') => void;
  activeSection: string;
  setActiveSection: (section: string) => void;
  currentRole: 'GUEST' | 'RESELLER' | 'AFFILIATE';
  onRoleChange: (role: 'GUEST' | 'RESELLER' | 'AFFILIATE') => void;
}

export function BottomNav({ 
  currentView, 
  onViewChange, 
  activeSection, 
  setActiveSection, 
  currentRole,
  onRoleChange
}: BottomNavProps) {
  const [showProfileDialog, setShowProfileDialog] = useState(false);
  const [isActivating, setIsActivating] = useState(false);
  const router = useRouter();
  const { toast } = useToast();

  const handleLogout = () => {
    onRoleChange('GUEST');
    onViewChange('HOME');
    setShowProfileDialog(false);
    toast({ title: "Sesi Berakhir", description: "Anda telah keluar dari mode kemitraan." });
  };

  const instantAffiliate = () => {
    setIsActivating(true);
    setTimeout(() => {
      setIsActivating(false);
      onRoleChange('AFFILIATE');
      onViewChange('DASHBOARD');
      setShowProfileDialog(false);
      toast({ title: "Affiliate Aktif!", description: "Mulai hasilkan komisi sekarang." });
    }, 1200);
  };

  const navItems = [
    { 
      id: 'home', 
      label: 'Beranda', 
      icon: <Home size={22} />, 
      action: () => {
        onViewChange('HOME');
        setActiveSection('home');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    },
    { 
      id: 'status', 
      label: 'Status', 
      icon: <ClipboardList size={22} />, 
      action: () => {
        onViewChange('STATUS');
        setActiveSection('status');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    },
    { 
      id: 'dashboard', 
      label: 'Panel', 
      icon: <Wallet size={22} />, 
      action: () => {
        if (currentRole === 'GUEST') {
          setShowProfileDialog(true);
        } else {
          onViewChange('DASHBOARD');
          setActiveSection('dashboard');
        }
      }
    },
    { 
      id: 'profile', 
      label: 'Akun', 
      icon: <User size={22} />, 
      action: () => {
        setShowProfileDialog(true);
      }
    },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[100] px-4 pb-6 md:hidden">
      <nav className="mx-auto max-w-md h-20 bg-[#121214]/80 backdrop-blur-3xl border border-white/10 rounded-[2.5rem] flex items-center justify-around px-6 shadow-2xl">
        {navItems.map((item) => {
          const isActive = 
            (item.id === 'home' && currentView === 'HOME' && activeSection === 'home') ||
            (item.id === 'status' && currentView === 'STATUS') ||
            (item.id === 'dashboard' && currentView === 'DASHBOARD') ||
            (item.id === 'profile' && showProfileDialog);

          return (
            <button
              key={item.id}
              onClick={item.action}
              className="flex flex-col items-center gap-1 group relative outline-none"
            >
              <div className={cn(
                "w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-300",
                isActive 
                  ? "bg-primary text-white scale-110 shadow-lg" 
                  : "text-slate-500"
              )}>
                {item.icon}
              </div>
              <span className={cn(
                "text-[9px] font-black uppercase tracking-widest transition-all",
                isActive ? "text-primary opacity-100" : "text-slate-500 opacity-60"
              )}>
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>

      <Dialog open={showProfileDialog} onOpenChange={setShowProfileDialog}>
        <DialogContent className="max-w-md bg-[#0A0A0B] border-white/10 text-white rounded-[3rem] p-10 shadow-2xl border-none">
          <DialogHeader>
            <DialogTitle className="text-3xl font-black uppercase tracking-tight text-center">PUSAT MITRA</DialogTitle>
            <DialogDescription className="text-center text-slate-500 text-[9px] font-black uppercase tracking-[0.3em] mt-2">
              PILIH METODE KEMITRAAN ANDA
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 mt-8">
            {currentRole === 'GUEST' ? (
              <div className="space-y-4">
                {/* Affiliate Option - Instant */}
                <div className="p-6 rounded-2xl bg-amber-500/5 border border-amber-500/10 space-y-4">
                  <div className="flex items-center gap-3">
                    <Zap size={24} className="text-amber-500" />
                    <div>
                      <p className="text-xs font-black uppercase">Affiliate VIP</p>
                      <p className="text-[8px] text-slate-500 font-bold uppercase">Instan • Tanpa Akun</p>
                    </div>
                  </div>
                  <Button 
                    onClick={instantAffiliate}
                    disabled={isActivating}
                    className="w-full h-14 rounded-xl bg-amber-500 hover:bg-amber-600 font-black uppercase text-[10px] tracking-widest"
                  >
                    {isActivating ? <RefreshCcw className="animate-spin" /> : "AKTIFKAN SEKARANG"}
                  </Button>
                </div>

                {/* Reseller Option - Traditional Signup */}
                <div className="p-6 rounded-2xl bg-primary/5 border border-primary/10 space-y-4">
                  <div className="flex items-center gap-3">
                    <TrendingUp size={24} className="text-primary" />
                    <div>
                      <p className="text-xs font-black uppercase">Master Reseller</p>
                      <p className="text-[8px] text-slate-500 font-bold uppercase">Harga Modal • Butuh Login</p>
                    </div>
                  </div>
                  <Button 
                    onClick={() => { router.push('/signup'); setShowProfileDialog(false); }}
                    className="w-full h-14 rounded-xl bg-primary hover:bg-primary/90 font-black uppercase text-[10px] tracking-widest"
                  >
                    DAFTAR AKUN BARU
                  </Button>
                </div>
                
                <Button 
                  onClick={() => { router.push('/login'); setShowProfileDialog(false); }}
                  variant="ghost"
                  className="w-full h-12 rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-500"
                >
                  SUDAH PUNYA AKUN? MASUK
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-6 rounded-2xl bg-white/5 border border-white/10 text-center">
                   <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">STATUS AKTIF</p>
                   <p className="text-2xl font-black text-primary uppercase mt-1">{currentRole}</p>
                </div>
                <Button 
                  onClick={() => { onViewChange('DASHBOARD'); setShowProfileDialog(false); }}
                  className="w-full h-18 rounded-2xl bg-primary font-black uppercase text-[10px] tracking-widest"
                >
                  BUKA PANEL DASHBOARD
                </Button>
                <Button 
                  onClick={handleLogout}
                  variant="ghost"
                  className="w-full h-18 rounded-2xl bg-rose-500/10 text-rose-500 font-black uppercase text-[10px] tracking-widest"
                >
                  KELUAR SESI
                </Button>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
