"use client"
import React, { useState } from 'react';
import { 
  Smartphone, Zap, Gamepad2, Wallet, 
  Tv, Globe, HeartPulse, Receipt, 
  Droplets, CreditCard, Ticket, PhoneCall,
  ChevronRight, Sparkles
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { PurchaseFlow } from './PurchaseFlow';

const SERVICES = [
  { id: 'pulsa', label: 'Pulsa', icon: <Smartphone />, color: 'bg-blue-500' },
  { id: 'data', label: 'Paket Data', icon: <Globe />, color: 'bg-emerald-500' },
  { id: 'pln', label: 'Token PLN', icon: <Zap />, color: 'bg-amber-500' },
  { id: 'game', label: 'Top Up Game', icon: <Gamepad2 />, color: 'bg-purple-500' },
  { id: 'ewallet', label: 'E-Wallet', icon: <Wallet />, color: 'bg-cyan-500' },
  { id: 'tv', label: 'TV Kabel', icon: <Tv />, color: 'bg-rose-500' },
  { id: 'bpjs', label: 'BPJS', icon: <HeartPulse />, color: 'bg-teal-500' },
  { id: 'pdam', label: 'PDAM', icon: <Droplets />, color: 'bg-sky-500' },
  { id: 'tagihan', label: 'Tagihan', icon: <Receipt />, color: 'bg-orange-500' },
  { id: 'cicilan', label: 'Cicilan', icon: <CreditCard />, color: 'bg-indigo-500' },
  { id: 'voucher', label: 'Voucher', icon: <Ticket />, color: 'bg-pink-500' },
  { id: 'telkom', label: 'Telkom', icon: <PhoneCall />, color: 'bg-red-500' },
];

export function ServiceGrid() {
  const [selectedService, setSelectedService] = useState<string | null>(null);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-black flex items-center gap-3">
          <Sparkles className="text-primary" size={20} /> LAYANAN PPOB
        </h2>
        <button className="text-[10px] font-bold text-primary uppercase tracking-widest hover:underline">
          Lihat Semua
        </button>
      </div>

      <div className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-4">
        {SERVICES.map((service) => (
          <button
            key={service.id}
            onClick={() => setSelectedService(service.id)}
            className="group flex flex-col items-center gap-3 p-4 rounded-3xl hover:bg-white/5 transition-all duration-300"
          >
            <div className={cn(
              "w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-xl transition-transform group-hover:scale-110",
              service.color
            )}>
              {React.cloneElement(service.icon as React.ReactElement, { size: 28 })}
            </div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tight text-center">
              {service.label}
            </span>
          </button>
        ))}
      </div>

      {selectedService && (
        <PurchaseFlow 
          category={selectedService} 
          onClose={() => setSelectedService(null)} 
        />
      )}
    </div>
  );
}