
"use client"
import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingUp, Users, Wallet, ArrowUpRight, 
  Banknote, History, Gift, Smartphone, 
  Zap, Globe, Share2, Copy, ShoppingBag,
  Sparkles, ShieldCheck, ChevronRight, TrendingDown,
  LineChart, MousePointerClick, RefreshCcw, CreditCard,
  GiftIcon, MessageCircle, AlertCircle
} from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { cn } from '@/lib/utils';

export function ResellerDashboard() {
  const [margin, setMargin] = useState(1500);
  const [mounted, setMounted] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    setMounted(true);
    const savedMargin = localStorage.getItem('reseller_margin');
    if (savedMargin) {
      setMargin(parseInt(savedMargin));
    }
  }, []);

  const saveMargin = () => {
    localStorage.setItem('reseller_margin', margin.toString());
    toast({ 
      title: "Margin Berhasil Disimpan", 
      description: `Margin keuntungan Anda kini ditetapkan sebesar Rp ${margin.toLocaleString('id-ID')}. Harga jual di beranda akan otomatis menyesuaikan.` 
    });
  };

  if (!mounted) return null;

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-8 duration-1000">
      {/* Premium Header Hero */}
      <div className="relative overflow-hidden p-10 md:p-16 rounded-[4rem] bg-gradient-to-br from-primary/30 via-primary/5 to-transparent border border-white/10 shadow-[0_32px_64px_-12px_rgba(0,0,0,0.5)] group">
         <div className="absolute top-0 right-0 w-96 h-96 bg-primary/20 rounded-full blur-[120px] -z-10 animate-pulse group-hover:bg-primary/30 transition-colors" />
         <div className="flex flex-col md:flex-row md:items-center justify-between gap-10">
            <div className="space-y-6">
               <div className="flex items-center gap-4">
                  <div className="bg-primary p-3 rounded-2xl text-white shadow-2xl shadow-primary/40 animate-bounce-slow">
                     <Sparkles size={28} />
                  </div>
                  <div className="flex flex-col">
                    <Badge className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-6 py-1.5 rounded-full font-black text-[10px] tracking-[0.2em] w-fit">STATUS: PLATINUM RESELLER</Badge>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.3em] mt-2 flex items-center gap-2">
                      <ShieldCheck size={14} className="text-primary"/> HARGA MASTER AKTIF & TERVERIFIKASI
                    </p>
                  </div>
               </div>
               <h2 className="text-5xl md:text-7xl font-black text-white tracking-tighter leading-[0.9]">DASHBOARD<br/><span className="text-primary">RESELLER</span></h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
               <Card className="glass-card p-8 rounded-[3rem] min-w-[220px] border-white/10 bg-white/[0.05] hover:bg-white/[0.08] transition-all cursor-default">
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 flex items-center gap-2"><RefreshCcw size={12}/> POIN REFRESH</p>
                  <p className="text-4xl font-black text-white">4,820</p>
               </Card>
               <Card className="bg-primary/20 p-8 rounded-[3rem] min-w-[220px] border border-primary/30 shadow-2xl shadow-primary/20 hover:scale-105 transition-transform cursor-default">
                  <p className="text-[10px] font-black text-primary-foreground/60 uppercase tracking-widest mb-2">LEVEL MEMBER</p>
                  <p className="text-4xl font-black text-white">LEGENDARY</p>
               </Card>
            </div>
         </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Kontrol Margin Keuntungan */}
        <Card className="glass-card rounded-[3.5rem] border-none p-12 space-y-8 relative group overflow-hidden bg-white/[0.02]">
          <div className="absolute -top-10 -right-10 p-4 opacity-5 group-hover:opacity-10 transition-all duration-700">
            <TrendingUp size={180} />
          </div>
          <div className="space-y-3 relative z-10">
            <h4 className="text-2xl font-black text-white tracking-tight">Setel Margin</h4>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.3em]">KEUNTUNGAN TETAP TIAP PRODUK</p>
          </div>
          <div className="relative z-10">
            <div className="absolute left-8 top-1/2 -translate-y-1/2 font-black text-primary text-3xl">Rp</div>
            <Input 
              type="number" 
              value={margin} 
              onChange={(e) => setMargin(parseInt(e.target.value) || 0)}
              className="pl-20 h-24 rounded-[2.5rem] bg-white/5 border-white/10 text-white font-black text-4xl focus:ring-4 focus:ring-primary/20 focus:border-primary transition-all text-center placeholder:text-white/10"
            />
          </div>
          <Button onClick={saveMargin} className="w-full h-20 rounded-[2.5rem] bg-primary hover:bg-primary/90 text-white font-black text-base uppercase tracking-[0.2em] shadow-[0_20px_40px_-10px_rgba(59,130,246,0.5)] active:scale-95 transition-all relative z-10">SIMPAN KONFIGURASI</Button>
        </Card>

        {/* Statistik Laba Estimasi */}
        <Card className="bg-white/[0.03] rounded-[3.5rem] border border-white/5 p-12 flex flex-col justify-between relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
          <div className="space-y-3 relative z-10">
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">ESTIMASI LABA BULAN INI</p>
            <h3 className="text-6xl font-black text-white tracking-tighter">Rp 2.85M</h3>
          </div>
          <div className="flex items-center gap-4 mt-8 bg-emerald-500/10 w-fit px-6 py-3 rounded-2xl border border-emerald-500/20 relative z-10">
            <TrendingUp size={18} className="text-emerald-400" />
            <span className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">+12.5% PERTUMBUHAN</span>
          </div>
        </Card>

        {/* Ringkasan Order Masuk */}
        <Card className="dana-gradient rounded-[3.5rem] border-none p-12 text-white shadow-[0_32px_64px_-12px_rgba(59,130,246,0.4)] flex flex-col justify-between group overflow-hidden">
           <div className="flex justify-between items-start relative z-10">
              <div className="p-4 bg-white/20 rounded-3xl backdrop-blur-xl border border-white/20 group-hover:scale-110 transition-transform">
                 <ShoppingBag size={32} />
              </div>
              <Badge className="bg-white/20 text-white border-none px-5 py-2 rounded-full font-black text-[9px] uppercase tracking-widest backdrop-blur-md">REALTIME DATA</Badge>
           </div>
           <div className="relative z-10">
              <p className="text-[10px] font-black text-white/60 uppercase tracking-[0.3em] mb-2">ORDER BERHASIL</p>
              <h3 className="text-5xl font-black tracking-tighter">1,204 <span className="text-sm font-bold opacity-50 tracking-normal ml-2">ITEMS</span></h3>
           </div>
        </Card>
      </div>

      <PointRedemptionSection />
    </div>
  );
}

function PointRedemptionSection() {
  const [showRedeemDialog, setShowRedeemDialog] = useState(false);
  const [selectedReward, setSelectedReward] = useState<any>(null);
  const [targetNumber, setTargetNumber] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const rewards = [
    { id: '1', title: "Saldo Toko Rp 50.000", cost: 5000, type: 'SALDO', icon: <Wallet/>, color: "text-emerald-400" },
    { id: '2', title: "Pulsa 20rb All Operator", cost: 2200, type: 'PULSA', icon: <Smartphone/>, color: "text-blue-400" },
    { id: '3', title: "Data 10GB 30 Hari", cost: 8500, type: 'DATA', icon: <Zap/>, color: "text-amber-400" },
    { id: '4', title: "E-Wallet Dana Rp 100rb", cost: 10500, type: 'E-WALLET', icon: <CreditCard/>, color: "text-cyan-400" },
  ];

  const handleRedeem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetNumber) {
      toast({ variant: "destructive", title: "Gagal", description: "Nomor tujuan wajib diisi." });
      return;
    }
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setShowRedeemDialog(false);
      toast({
        title: "Penukaran Berhasil",
        description: `Permintaan ${selectedReward.title} sedang diproses untuk nomor ${targetNumber}.`,
      });
      setTargetNumber('');
    }, 2000);
  };

  return (
    <div className="space-y-8 pt-6">
      <div className="flex items-center justify-between">
         <div className="flex items-center gap-4">
            <div className="w-1.5 h-10 bg-primary rounded-full" />
            <h3 className="text-3xl font-black text-white uppercase tracking-tight">KATALOG PENUKARAN POIN</h3>
         </div>
      </div>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
         {rewards.map((item) => (
           <Card key={item.id} className="glass-card rounded-[3rem] p-8 space-y-6 text-center hover:bg-white/[0.08] border-white/10 hover:border-primary/50 transition-all cursor-pointer group">
              <div className={cn("w-20 h-20 rounded-[1.5rem] flex items-center justify-center mx-auto transition-all bg-black/40", item.color)}>
                 {React.cloneElement(item.icon as React.ReactElement, { size: 32 })}
              </div>
              <div className="space-y-1">
                 <h4 className="font-black text-lg text-white leading-tight">{item.title}</h4>
                 <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">{item.cost.toLocaleString()} POIN</p>
              </div>
              <Button 
                onClick={() => { setSelectedReward(item); setShowRedeemDialog(true); }}
                className="w-full rounded-2xl h-12 text-[10px] font-black uppercase tracking-widest bg-white/5 border border-white/10 hover:bg-primary hover:border-primary"
              >
                TUKAR SEKARANG
              </Button>
           </Card>
         ))}
      </div>

      <Dialog open={showRedeemDialog} onOpenChange={setShowRedeemDialog}>
        <DialogContent className="max-w-md bg-[#0A0A0B] border-white/10 text-white rounded-[3rem] p-10 focus:outline-none shadow-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black uppercase tracking-tight text-center">KONFIRMASI PENUKARAN</DialogTitle>
            <DialogDescription className="text-center text-slate-500 text-[9px] font-black uppercase tracking-[0.3em] mt-2">
              {selectedReward?.title}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleRedeem} className="space-y-6 mt-8">
            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 text-center">
               <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">BIAYA POIN</p>
               <p className="text-3xl font-black text-primary">{selectedReward?.cost.toLocaleString()} <span className="text-sm">POIN</span></p>
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-2">NOMOR TUJUAN (HP / ID)</label>
              <Input 
                placeholder="Contoh: 081234567890" 
                value={targetNumber}
                onChange={(e) => setTargetNumber(e.target.value)}
                className="h-16 rounded-2xl bg-white/5 border-white/10 font-black text-lg text-white px-6 focus:ring-primary/20"
                required
              />
            </div>

            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 flex gap-3 items-start">
               <AlertCircle size={16} className="text-amber-500 shrink-0 mt-0.5" />
               <p className="text-[9px] font-bold text-amber-500/80 leading-relaxed uppercase">
                 Pastikan nomor tujuan sudah benar. Kesalahan input nomor tidak dapat dibatalkan atau direfund poinnya.
               </p>
            </div>

            <Button 
              type="submit" 
              disabled={isProcessing}
              className="w-full h-18 rounded-2xl bg-primary hover:bg-primary/90 font-black uppercase tracking-widest text-white shadow-xl shadow-primary/20"
            >
              {isProcessing ? <RefreshCcw className="animate-spin" /> : "KONFIRMASI PENUKARAN"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export function AffiliateDashboard() {
  const [mounted, setMounted] = useState(false);
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const referralCode = "ABDI-VIP-2025";

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleCopy = () => {
    if (typeof navigator !== 'undefined') {
      navigator.clipboard.writeText(referralCode);
      toast({ title: "Kode Tersalin", description: "Bagikan kode referral Anda dan raih komisi Rp 800!" });
    }
  };

  const handleWithdraw = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || parseInt(amount) < 50000) {
       toast({ variant: "destructive", title: "Gagal", description: "Minimal penarikan adalah Rp 50.000." });
       return;
    }
    setLoading(true);
    setTimeout(() => {
       setLoading(false);
       toast({ title: "Permintaan Terkirim", description: "Penarikan Anda sedang diproses oleh admin (Estimasi 1-24 jam)." });
       setAmount('');
    }, 2000);
  };

  if (!mounted) return null;

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-1000">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white/[0.02] p-8 rounded-[3rem] border border-white/5">
        <div>
          <h2 className="text-4xl font-black text-white uppercase tracking-tighter">Panel Affiliate</h2>
          <p className="text-[11px] text-slate-500 font-bold uppercase tracking-[0.3em] mt-2 flex items-center gap-2">
            <Zap size={14} className="text-amber-500"/> KOMISI Rp 800 TIAP TRANSAKSI REFERRAL
          </p>
        </div>
        <div className="flex items-center gap-4">
           <div className="bg-white/5 px-8 py-5 rounded-[2rem] border border-white/10 flex items-center gap-6 shadow-2xl backdrop-blur-xl group hover:border-primary/50 transition-colors">
              <div className="flex flex-col">
                <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">REFERRAL CODE</span>
                <span className="text-sm font-black text-primary tracking-[0.2em]">{referralCode}</span>
              </div>
              <button onClick={handleCopy} className="p-3 bg-white/5 rounded-xl text-slate-400 hover:text-white hover:bg-primary transition-all active:scale-90"><Copy size={18}/></button>
           </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <Card className="glass-card rounded-[4rem] border-none p-12 bg-primary/10 relative overflow-hidden flex flex-col justify-center min-h-[320px] group shadow-[0_32px_64px_-12px_rgba(59,130,246,0.3)]">
          <div className="absolute top-0 right-0 w-80 h-80 bg-primary/20 rounded-full blur-[100px] group-hover:scale-125 transition-transform duration-1000" />
          <p className="text-[12px] font-black text-primary uppercase tracking-[0.4em] mb-4">SALDO KOMISI AKTIF</p>
          <h3 className="text-8xl font-black text-white tracking-tighter drop-shadow-2xl">Rp 158.400</h3>
          <Wallet className="absolute -bottom-16 -right-16 w-80 h-80 text-primary/5 -z-10 group-hover:rotate-12 transition-transform duration-700" />
        </Card>
        <div className="grid grid-cols-2 gap-6">
            <Card className="glass-card rounded-[3.5rem] p-10 text-center space-y-3 flex flex-col justify-center bg-white/[0.02] border-white/10 hover:bg-white/[0.05] transition-all cursor-default">
              <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center mx-auto mb-2 text-primary"><MousePointerClick size={24}/></div>
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">TOTAL KLIK REFERRAL</p>
              <p className="text-6xl font-black text-white">1,204</p>
            </Card>
            <Card className="glass-card rounded-[3.5rem] p-10 text-center space-y-3 flex flex-col justify-center bg-white/[0.02] border-white/10 hover:bg-white/[0.05] transition-all cursor-default">
              <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center mx-auto mb-2 text-emerald-500"><LineChart size={24}/></div>
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">TRANSAKSI SUKSES</p>
              <p className="text-6xl font-black text-emerald-400">450</p>
            </Card>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-8">
        <TabsList className="bg-white/5 border border-white/10 p-2 rounded-[2.5rem] h-24 w-fit flex gap-2 backdrop-blur-md">
          <TabsTrigger value="overview" className="rounded-[2rem] px-12 font-black text-[11px] uppercase tracking-widest data-[state=active]:bg-primary data-[state=active]:text-white data-[state=active]:shadow-2xl transition-all h-full">PERFORMA</TabsTrigger>
          <TabsTrigger value="redeem" className="rounded-[2rem] px-12 font-black text-[11px] uppercase tracking-widest data-[state=active]:bg-primary data-[state=active]:text-white data-[state=active]:shadow-2xl transition-all h-full">TUKAR POIN</TabsTrigger>
          <TabsTrigger value="withdraw" className="rounded-[2rem] px-12 font-black text-[11px] uppercase tracking-widest data-[state=active]:bg-primary data-[state=active]:text-white data-[state=active]:shadow-2xl transition-all h-full">PENARIKAN</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
           <Card className="glass-card rounded-[4rem] p-16 border-none bg-white/[0.01] shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-primary/50 to-emerald-500/50" />
              <div className="flex items-center justify-between mb-12">
                <div>
                  <p className="text-[11px] font-black text-slate-500 uppercase tracking-[0.4em]">ANALISA TREND 7 HARI TERAKHIR</p>
                  <p className="text-xs font-bold text-white mt-2 opacity-50 italic">* Menampilkan data pertumbuhan klik dan transaksi</p>
                </div>
                <div className="flex items-center gap-6">
                  <div className="flex items-center gap-2.5"><div className="w-4 h-4 bg-primary rounded-full shadow-[0_0_10px_rgba(59,130,246,0.5)]" /><span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">KLIK</span></div>
                  <div className="flex items-center gap-2.5"><div className="w-4 h-4 bg-emerald-500 rounded-full shadow-[0_0_10px_rgba(16,185,129,0.5)]" /><span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">TRANSAKSI</span></div>
                </div>
              </div>
              <div className="h-72 flex items-end justify-between gap-6">
                 {[40, 70, 45, 90, 65, 80, 55].map((h, i) => (
                   <div key={i} className="flex-1 bg-primary/10 hover:bg-primary/40 rounded-3xl transition-all duration-500 relative group cursor-pointer border border-white/5" style={{ height: `${h}%` }}>
                      <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-white text-black px-3 py-1.5 rounded-xl text-[10px] font-black opacity-0 group-hover:opacity-100 transition-all shadow-2xl whitespace-nowrap">
                        {h * 12} Klik
                      </div>
                      <div className="absolute bottom-0 left-0 w-full h-1/2 bg-emerald-500/30 rounded-3xl opacity-50 group-hover:opacity-100 transition-all" />
                   </div>
                 ))}
              </div>
           </Card>
        </TabsContent>

        <TabsContent value="redeem">
           <PointRedemptionSection />
        </TabsContent>

        <TabsContent value="withdraw" className="max-w-3xl mx-auto">
           <Card className="glass-card rounded-[4rem] p-16 space-y-12 border-none bg-white/[0.02] shadow-[0_48px_96px_-12px_rgba(0,0,0,0.5)] relative overflow-hidden">
              <div className="absolute -top-20 -left-20 w-64 h-64 bg-primary/10 rounded-full blur-[100px]" />
              <div className="text-center space-y-4 relative z-10">
                 <h3 className="font-black text-4xl uppercase tracking-tighter text-white">PENARIKAN KOMISI</h3>
                 <p className="text-[11px] text-slate-500 font-bold uppercase tracking-[0.4em]">MINIMAL PENCAIRAN: Rp 50.000</p>
              </div>
              <form onSubmit={handleWithdraw} className="space-y-8 relative z-10">
                 <div className="space-y-4">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-6">NOMINAL PENARIKAN (Rp)</label>
                    <div className="relative">
                       <span className="absolute left-8 top-1/2 -translate-y-1/2 font-black text-primary text-2xl">Rp</span>
                       <Input 
                          placeholder="0" 
                          type="number" 
                          value={amount}
                          onChange={(e) => setAmount(e.target.value)}
                          className="pl-20 h-24 rounded-[2.5rem] bg-white/5 border-white/10 font-black text-3xl text-white focus:ring-4 focus:ring-primary/20 focus:border-primary transition-all placeholder:text-white/5" 
                       />
                    </div>
                 </div>
                 <div className="grid md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                       <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-6">PILIH METODE</label>
                       <Select required>
                          <SelectTrigger className="h-20 rounded-[2rem] bg-white/5 border-white/10 font-black text-sm text-white px-8 focus:ring-primary/20">
                             <SelectValue placeholder="BANK / E-WALLET" />
                          </SelectTrigger>
                          <SelectContent className="bg-[#0A0A0B] border-white/10 text-white rounded-[2rem] p-2">
                             <SelectItem value="BCA" className="rounded-xl py-3 px-6 focus:bg-primary font-bold">BCA (BANK CENTRAL ASIA)</SelectItem>
                             <SelectItem value="BNI" className="rounded-xl py-3 px-6 focus:bg-primary font-bold">BNI (BANK NEGARA INDONESIA)</SelectItem>
                             <SelectItem value="MANDIRI" className="rounded-xl py-3 px-6 focus:bg-primary font-bold">BANK MANDIRI</SelectItem>
                             <SelectItem value="DANA" className="rounded-xl py-3 px-6 focus:bg-primary font-bold">DANA E-WALLET</SelectItem>
                             <SelectItem value="OVO" className="rounded-xl py-3 px-6 focus:bg-primary font-bold">OVO E-WALLET</SelectItem>
                             <SelectItem value="GOPAY" className="rounded-xl py-3 px-6 focus:bg-primary font-bold">GOPAY E-WALLET</SelectItem>
                             <SelectItem value="SHOPEE" className="rounded-xl py-3 px-6 focus:bg-primary font-bold">SHOPEEPAY</SelectItem>
                          </SelectContent>
                       </Select>
                    </div>
                    <div className="space-y-4">
                       <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-6">NOMOR REKENING / HP</label>
                       <Input required placeholder="Masukkan nomor tujuan" className="h-20 rounded-[2rem] bg-white/5 border-white/10 font-black text-sm text-white px-8 focus:ring-primary/20" />
                    </div>
                 </div>
                 <div className="space-y-4">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-6">ATAS NAMA PEMILIK</label>
                    <Input required placeholder="Nama lengkap sesuai rekening" className="h-20 rounded-[2rem] bg-white/5 border-white/10 font-black text-sm text-white px-8 focus:ring-primary/20" />
                 </div>
                 <Button type="submit" disabled={loading} className="w-full h-24 rounded-[3rem] bg-primary hover:bg-primary/90 font-black uppercase tracking-[0.3em] shadow-[0_24px_48px_-12px_rgba(59,130,246,0.6)] active:scale-[0.98] transition-all text-base border-none">
                    {loading ? <RefreshCcw className="animate-spin mr-3"/> : "PROSES PENCAIRAN DANA"}
                 </Button>
                 <p className="text-[9px] text-center text-slate-500 font-bold uppercase tracking-[0.2em] italic">* Pastikan data rekening Anda valid untuk menghindari kegagalan sistem.</p>
              </form>
           </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
