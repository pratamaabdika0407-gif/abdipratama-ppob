
"use client"
import React, { useState, useEffect } from 'react';
import { 
  Menu, User, Wallet, 
  ShieldCheck, TrendingUp, LogOut, 
  LayoutDashboard, Zap, Sparkles, Home,
  RefreshCcw, ArrowRight, ClipboardList
} from 'lucide-react';
import Link from 'next/link';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useRouter } from 'next/navigation';

interface DanaHeaderProps {
  onRoleChange?: (role: 'GUEST' | 'RESELLER' | 'AFFILIATE') => void;
  onViewChange?: (view: 'HOME' | 'DASHBOARD' | 'STATUS') => void;
  currentRole: 'GUEST' | 'RESELLER' | 'AFFILIATE';
  currentView: 'HOME' | 'DASHBOARD' | 'STATUS';
}

export function DanaHeader({ onRoleChange, onViewChange, currentRole, currentView }: DanaHeaderProps) {
  const [mounted, setMounted] = useState(false);
  const [showAffiliateDialog, setShowAffiliateDialog] = useState(false);
  const [isPending, setIsPending] = useState(false);
  const { toast } = useToast();
  const router = useRouter();

  useEffect(() => {
    setMounted(true);
  }, []);

  const activateAffiliate = () => {
    setIsPending(true);
    setTimeout(() => {
      setIsPending(false);
      setShowAffiliateDialog(false);
      toast({
        title: "Affiliate Aktif!",
        description: `Selamat! Anda kini adalah Affiliate VIP. Mulai bagikan kode referral Anda.`,
      });
      if (onRoleChange) onRoleChange('AFFILIATE');
      if (onViewChange) onViewChange('DASHBOARD');
    }, 1500);
  };

  const handleLogout = () => {
    if (onRoleChange) onRoleChange('GUEST');
    if (onViewChange) onViewChange('HOME');
    toast({
      title: "Berhasil Keluar",
      description: "Anda telah keluar dari sesi kemitraan.",
    });
  };

  if (!mounted) return null;

  return (
    <header className="sticky top-0 z-[100] bg-[#0A0A0B]/90 backdrop-blur-2xl border-b border-white/5">
      <div className="container mx-auto px-4 h-28 flex items-center justify-between">
        {/* Logo Section */}
        <Link href="/" className="flex items-center gap-4 group shrink-0">
          <div className="w-14 h-14 rounded-[1.5rem] bg-primary flex items-center justify-center text-white shadow-2xl shadow-primary/40 group-hover:rotate-6 transition-all active:scale-90">
            <Wallet size={32} />
          </div>
          <div className="flex flex-col">
            <span className="font-black text-3xl tracking-tighter leading-none text-white group-hover:text-primary transition-colors">ABDI PRATAMA</span>
            <div className="flex items-center gap-2 mt-1.5">
              <span className="text-[11px] font-black text-primary uppercase tracking-[0.4em]">PPOB ECOSYSTEM</span>
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_12px_rgba(16,185,129,0.8)]" />
            </div>
          </div>
        </Link>

        {/* Desktop Navigation Links */}
        <nav className="hidden xl:flex items-center gap-12 text-[12px] font-black text-slate-500 uppercase tracking-[0.4em]">
          <button 
            onClick={() => onViewChange?.('HOME')} 
            className={cn("hover:text-white transition-all hover:tracking-[0.5em]", currentView === 'HOME' && "text-white tracking-[0.5em]")}
          >
            Beranda
          </button>
          <button 
            onClick={() => onViewChange?.('STATUS')} 
            className={cn("hover:text-white transition-all hover:tracking-[0.5em]", currentView === 'STATUS' && "text-white tracking-[0.5em]")}
          >
            Status
          </button>
          <button className="hover:text-white transition-all hover:tracking-[0.5em]">Promo</button>
          <Link href="/admin/login" className="flex items-center gap-3 text-primary hover:text-white transition-all group">
            <ShieldCheck size={18} className="group-hover:scale-110 transition-transform" />
            ADMIN PANEL
          </Link>
        </nav>

        {/* Action Controls */}
        <div className="flex items-center gap-4">
          {currentRole !== 'GUEST' && (
            <Button 
              onClick={() => onViewChange?.('DASHBOARD')}
              variant="ghost" 
              className={cn(
                "hidden md:flex h-14 rounded-3xl gap-3 px-6 font-black text-[10px] uppercase tracking-widest border transition-all active:scale-95",
                currentRole === 'RESELLER' 
                  ? "bg-primary/10 border-primary/20 text-primary hover:bg-primary/20" 
                  : "bg-amber-500/10 border-amber-500/20 text-amber-500 hover:bg-amber-500/20"
              )}
            >
              <LayoutDashboard size={18} /> {currentRole} PANEL
            </Button>
          )}

          {/* Profile Dropdown */}
          <DropdownMenu modal={false}>
            <DropdownMenuTrigger asChild>
              <button className="outline-none group">
                <div className={cn(
                  "p-0.5 rounded-full transition-all duration-500 group-hover:scale-110 active:scale-95",
                  currentRole === 'GUEST' ? "bg-white/10" : currentRole === 'RESELLER' ? "bg-primary p-1" : "bg-amber-500 p-1"
                )}>
                  <Avatar className="w-12 h-12 border-2 border-[#0A0A0B]">
                    <AvatarImage src={currentRole === 'GUEST' ? "" : `https://picsum.photos/seed/${currentRole}/100/100`} />
                    <AvatarFallback className="bg-slate-800 text-white font-black"><User size={24}/></AvatarFallback>
                  </Avatar>
                </div>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-80 bg-[#0A0A0B] border-white/10 text-white rounded-[3rem] shadow-2xl p-3 mt-4" align="end">
              <DropdownMenuLabel className="px-6 py-6 text-center">
                <span className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-500">MODE SAAT INI</span>
                <p className="text-xl font-black text-white uppercase tracking-tight mt-1">{currentRole === 'GUEST' ? 'PENGUNJUNG' : currentRole}</p>
              </DropdownMenuLabel>
              
              <DropdownMenuSeparator className="bg-white/5 mx-4" />
              
              {currentRole === 'GUEST' ? (
                <div className="p-2 space-y-1">
                  <DropdownMenuItem 
                    onSelect={() => router.push('/signup')} 
                    className="flex items-center gap-4 p-5 rounded-[1.5rem] cursor-pointer hover:bg-primary/10 group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                      <TrendingUp size={20} />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="font-black text-xs uppercase tracking-widest">DAFTAR RESELLER</span>
                      <span className="text-[9px] text-slate-500 font-bold uppercase">BUTUH AKUN & VERIFIKASI</span>
                    </div>
                  </DropdownMenuItem>

                  <DropdownMenuItem 
                    onSelect={() => setShowAffiliateDialog(true)} 
                    className="flex items-center gap-4 p-5 rounded-[1.5rem] cursor-pointer hover:bg-amber-500/10 group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-500 group-hover:scale-110 transition-transform">
                      <Zap size={20} />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="font-black text-xs uppercase tracking-widest">AKTIFKAN AFFILIATE</span>
                      <span className="text-[9px] text-slate-500 font-bold uppercase">INSTAN TANPA DAFTAR</span>
                    </div>
                  </DropdownMenuItem>
                </div>
              ) : (
                <div className="p-2 space-y-1">
                  <DropdownMenuItem 
                    onSelect={() => onViewChange?.('DASHBOARD')} 
                    className="flex items-center gap-4 p-5 rounded-[1.5rem] cursor-pointer hover:bg-primary/10 group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                      <LayoutDashboard size={20} />
                    </div>
                    <span className="font-black text-xs uppercase tracking-widest">BUKA PANEL DASHBOARD</span>
                  </DropdownMenuItem>
                </div>
              )}

              <DropdownMenuSeparator className="bg-white/5 mx-4" />
              
              <div className="p-2">
                <DropdownMenuItem 
                  onSelect={() => onViewChange?.('STATUS')} 
                  className="flex items-center gap-4 p-5 rounded-[1.5rem] cursor-pointer hover:bg-white/5"
                >
                  <ClipboardList size={20} className="text-slate-400" />
                  <span className="font-black text-xs uppercase tracking-widest">STATUS PESANAN</span>
                </DropdownMenuItem>
                
                {currentRole !== 'GUEST' && (
                  <DropdownMenuItem 
                    onSelect={handleLogout} 
                    className="flex items-center gap-4 p-5 rounded-[1.5rem] cursor-pointer hover:bg-rose-500/10 text-rose-500"
                  >
                    <LogOut size={20} />
                    <span className="font-black text-xs uppercase tracking-widest">KELUAR DARI MODE</span>
                  </DropdownMenuItem>
                )}
              </div>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Hamburger Menu */}
          <DropdownMenu modal={false}>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-14 w-14 rounded-3xl bg-white/5 border border-white/10 p-0 text-white hover:bg-white/10 transition-all shadow-xl">
                <Menu size={32} />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-72 bg-[#0A0A0B] border-white/10 text-white rounded-[2.5rem] shadow-2xl p-2 mt-4" align="end">
               <div className="p-2 space-y-1">
                 <DropdownMenuItem onSelect={() => onViewChange?.('HOME')} className="p-5 rounded-2xl gap-4 cursor-pointer hover:bg-white/5">
                   <Home size={20} className="text-primary"/> <span className="font-black text-xs uppercase tracking-widest">BERANDA</span>
                 </DropdownMenuItem>
                 
                 <DropdownMenuItem onSelect={() => onViewChange?.('STATUS')} className="p-5 rounded-2xl gap-4 cursor-pointer hover:bg-white/5">
                   <ClipboardList size={20} className="text-primary"/> <span className="font-black text-xs uppercase tracking-widest">STATUS PESANAN</span>
                 </DropdownMenuItem>

                 {currentRole === 'GUEST' ? (
                   <>
                     <DropdownMenuItem onSelect={() => router.push('/login')} className="p-5 rounded-2xl gap-4 cursor-pointer hover:bg-white/5">
                       <User size={20} className="text-slate-400"/> <span className="font-black text-xs uppercase tracking-widest">LOGIN RESELLER</span>
                     </DropdownMenuItem>
                     <DropdownMenuItem onSelect={() => setShowAffiliateDialog(true)} className="p-5 rounded-2xl gap-4 cursor-pointer hover:bg-amber-500/10 text-amber-500">
                       <Zap size={20}/> <span className="font-black text-xs uppercase tracking-widest">AKTIFKAN AFFILIATE</span>
                     </DropdownMenuItem>
                   </>
                 ) : (
                   <DropdownMenuItem onSelect={handleLogout} className="p-5 rounded-2xl gap-4 cursor-pointer hover:bg-rose-500/10 text-rose-500">
                     <LogOut size={20}/> <span className="font-black text-xs uppercase tracking-widest">KELUAR SESI</span>
                   </DropdownMenuItem>
                 )}
               </div>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Affiliate Activation Dialog */}
      <Dialog open={showAffiliateDialog} onOpenChange={setShowAffiliateDialog}>
        <DialogContent className="max-w-xl bg-[#0A0A0B] border-white/10 text-white rounded-[4rem] p-16 shadow-2xl border-none">
          <div className="absolute top-0 left-0 w-full h-3 bg-amber-500 rounded-t-[4rem]" />
          <DialogHeader>
            <DialogTitle className="text-5xl font-black uppercase tracking-tighter text-center leading-[0.9]">
              AKTIVASI <br/><span className="text-amber-500">AFFILIATE</span>
            </DialogTitle>
            <DialogDescription className="text-center text-slate-500 text-[11px] mt-6 font-black uppercase tracking-[0.5em]">
              TANPA LOGIN • LANGSUNG HASILKAN CUAN
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-12 mt-12">
            <div className="p-12 rounded-[3.5rem] bg-white/[0.03] border border-white/10 text-center space-y-8 group">
              <div className="mx-auto w-24 h-24 rounded-[2.5rem] bg-amber-500/20 flex items-center justify-center text-amber-500 shadow-2xl group-hover:scale-110 transition-all">
                 <Sparkles size={48} />
              </div>
              <div className="space-y-3">
                <h3 className="text-4xl font-black tracking-tight text-white uppercase leading-none">KOMISI Rp 800</h3>
                <p className="text-[12px] text-slate-400 font-bold uppercase tracking-widest leading-relaxed">
                  Dapatkan komisi instan untuk setiap transaksi yang menggunakan kode referral Anda. Tidak perlu akun, cukup aktifkan dan bagikan!
                </p>
              </div>
            </div>
            <Button 
              onClick={activateAffiliate} 
              disabled={isPending}
              className="w-full h-28 rounded-[3rem] bg-amber-500 hover:bg-amber-600 text-white font-black uppercase tracking-[0.4em] shadow-2xl shadow-amber-500/40 text-lg border-none flex items-center justify-center gap-4"
            >
              {isPending ? <RefreshCcw className="animate-spin" size={28}/> : (
                <>AKTIFKAN SEKARANG <ArrowRight size={24}/></>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </header>
  );
}
