
"use client"
import React, { useState, useEffect, useRef } from 'react';
import { 
  X, Check, Loader2, Smartphone, 
  ArrowRight, QrCode, Upload, ShieldCheck, 
  UserCheck, ImageIcon, TicketPercent, Wallet,
  Gamepad2, Zap, Globe, Receipt, CreditCard,
  PhoneCall, Tv, HeartPulse, Droplets, Monitor,
  Gamepad, ShoppingBag, Coins, TrendingUp
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { checkCustomerName } from '@/ai/flows/customer-inquiry';
import { cn } from '@/lib/utils';
import Image from 'next/image';
import { useToast } from '@/hooks/use-toast';

// Konfigurasi Game Lengkap dengan Brand Colors
const GAME_LIST = [
  { id: 'ml', name: 'Mobile Legends', hint: 'User ID + Zone ID', icon: <Gamepad2 />, color: 'bg-[#2196F3]' },
  { id: 'ff', name: 'Free Fire', hint: 'Player ID', icon: <Zap />, color: 'bg-[#FF5722]' },
  { id: 'pubg', name: 'PUBG Mobile', hint: 'Character ID', icon: <Smartphone />, color: 'bg-[#FBC02D]' },
  { id: 'genshin', name: 'Genshin Impact', hint: 'UID + Server', icon: <Globe />, color: 'bg-[#00BFA5]' },
  { id: 'valorant', name: 'Valorant', hint: 'Riot ID + Tag', icon: <Gamepad2 />, color: 'bg-[#FF4655]' },
  { id: 'roblox', name: 'Roblox', hint: 'Username', icon: <TicketPercent />, color: 'bg-[#000000]' },
  { id: 'codm', name: 'COD Mobile', hint: 'OpenID', icon: <Smartphone />, color: 'bg-[#37474F]' },
  { id: 'hsr', name: 'Honkai: Star Rail', hint: 'UID', icon: <Globe />, color: 'bg-[#673AB7]' },
  { id: 'pb', name: 'Point Blank', hint: 'Username', icon: <Gamepad2 />, color: 'bg-[#D32F2F]' },
  { id: 'aov', name: 'Arena of Valor', hint: 'OpenID', icon: <Gamepad />, color: 'bg-[#1565C0]' },
  { id: 'lol', name: 'Wild Rift', hint: 'Riot ID', icon: <Monitor />, color: 'bg-[#1976D2]' },
  { id: 'apex', name: 'Apex Legends', hint: 'Player ID', icon: <Zap />, color: 'bg-[#B71C1C]' },
  { id: 'steam', name: 'Steam Wallet', hint: 'Steam ID', icon: <ShoppingBag />, color: 'bg-[#171A21]' },
  { id: 'minecraft', name: 'Minecraft', hint: 'Username', icon: <Gamepad />, color: 'bg-[#4E7837]' },
  { id: 'supercell', name: 'Clash of Clans', hint: 'Player Tag', icon: <Coins />, color: 'bg-[#F9A825]' },
];

// Konfigurasi Operator Data/Pulsa Lengkap
const OPERATORS = [
  { id: 'tsel', name: 'Telkomsel', hint: 'Nomor Telkomsel', icon: <PhoneCall />, color: 'bg-[#ED1C24]' },
  { id: 'isat', name: 'Indosat Ooredoo', hint: 'Nomor Indosat', icon: <Globe />, color: 'bg-[#FFCC00]' },
  { id: 'xl', name: 'XL Axiata', hint: 'Nomor XL', icon: <Globe />, color: 'bg-[#0055AA]' },
  { id: 'axis', name: 'Axis', hint: 'Nomor Axis', icon: <Zap />, color: 'bg-[#8B008B]' },
  { id: 'tri', name: 'Three (3)', hint: 'Nomor Tri', icon: <PhoneCall />, color: 'bg-[#000000]' },
  { id: 'smart', name: 'Smartfren', hint: 'Nomor Smartfren', icon: <Globe />, color: 'bg-[#E91E63]' },
  { id: 'byu', name: 'by.U', hint: 'Nomor by.U', icon: <Smartphone />, color: 'bg-[#00B4D8]' },
];

// Konfigurasi E-Wallet Lengkap
const EWALLET_LIST = [
  { id: 'dana', name: 'DANA', hint: 'Nomor HP DANA', icon: <Wallet />, color: 'bg-[#008CFF]' },
  { id: 'ovo', name: 'OVO', hint: 'Nomor HP OVO', icon: <Wallet />, color: 'bg-[#4C2A86]' },
  { id: 'gopay', name: 'GoPay', hint: 'Nomor HP GoPay', icon: <Wallet />, color: 'bg-[#00AED6]' },
  { id: 'shopeepay', name: 'ShopeePay', hint: 'Nomor HP ShopeePay', icon: <Wallet />, color: 'bg-[#EE4D2D]' },
  { id: 'linkaja', name: 'LinkAja', hint: 'Nomor HP LinkAja', icon: <Wallet />, color: 'bg-[#E61E2A]' },
  { id: 'maxim', name: 'Maxim Driver', hint: 'ID Maxim', icon: <CreditCard />, color: 'bg-[#FFD600]' },
  { id: 'isaku', name: 'i.saku', hint: 'Nomor HP i.saku', icon: <ShoppingBag />, color: 'bg-[#00529C]' },
  { id: 'sakuku', name: 'Sakuku', hint: 'Nomor HP Sakuku', icon: <Wallet />, color: 'bg-[#005FB8]' },
  { id: 'grabpay', name: 'GrabPay', hint: 'Nomor HP Grab', icon: <Wallet />, color: 'bg-[#00B14F]' },
  { id: 'dokupay', name: 'DOKU Wallet', hint: 'ID DOKU', icon: <CreditCard />, color: 'bg-[#E11922]' },
  { id: 'kaspro', name: 'Kaspro', hint: 'Nomor Kaspro', icon: <Wallet />, color: 'bg-[#29B6F6]' },
];

const RAW_PRODUCTS = [
  { id: 'P1', label: '1.000', price: 1500, basePrice: 1050, points: 5 },
  { id: 'P5', label: '5.000', price: 6500, basePrice: 5100, points: 25 },
  { id: 'P10', label: '10.000', price: 11500, basePrice: 10100, points: 50 },
  { id: 'P20', label: '20.000', price: 21200, basePrice: 20050, points: 100 },
  { id: 'P50', label: '50.000', price: 50800, basePrice: 50050, points: 250 },
  { id: 'P100', label: '100.000', price: 100500, basePrice: 100050, points: 500 },
];

export function PurchaseFlow({ category, onClose }: { category: string, onClose: () => void }) {
  const needsProviderSelection = ['game', 'data', 'ewallet', 'pulsa'].includes(category);
  const [step, setStep] = useState(needsProviderSelection ? 0 : 1);
  
  const [selectedProvider, setSelectedProvider] = useState<any>(null);
  const [target, setTarget] = useState('');
  const [customerName, setCustomerName] = useState<string | null>(null);
  const [loadingName, setLoadingName] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [discountCode, setDiscountCode] = useState('');
  const [userRole, setUserRole] = useState('GUEST');
  const [resellerMargin, setResellerMargin] = useState(1500);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    const role = localStorage.getItem('user_role') || 'GUEST';
    const margin = localStorage.getItem('reseller_margin');
    setUserRole(role);
    if (margin) setResellerMargin(parseInt(margin));
  }, []);

  useEffect(() => {
    if (target.length >= 8) {
      const timer = setTimeout(() => handleCheckName(), 500);
      return () => clearTimeout(timer);
    }
  }, [target]);

  const handleCheckName = async () => {
    setLoadingName(true);
    try {
      const res = await checkCustomerName({ targetNumber: target, serviceType: category });
      setCustomerName(res.customerName);
    } catch (e) {
      setCustomerName("PELANGGAN SETIA");
    } finally {
      setLoadingName(false);
    }
  };

  const handleNext = () => {
    if (step === 0 && selectedProvider) {
      setStep(1);
    } else if (step === 1 && target.length >= 5) {
      setStep(2);
    } else if (step === 2 && selectedProduct) {
      setIsProcessing(true);
      setTimeout(() => { 
        setIsProcessing(false); 
        setStep(3); 
      }, 800);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setUploading(true);
      setTimeout(() => {
        setUploading(false);
        toast({ 
          title: "Pembayaran Diterima", 
          description: `Bukti berhasil dikirim. Anda mendapatkan ${selectedProduct?.points || 0} Poin Referral!` 
        });
        onClose();
      }, 1500);
    }
  };

  const getStepZeroList = () => {
    if (category === 'game') return GAME_LIST;
    if (category === 'data' || category === 'pulsa') return OPERATORS;
    if (category === 'ewallet') return EWALLET_LIST;
    return [];
  };

  const productsToDisplay = RAW_PRODUCTS.map(p => {
    if (userRole === 'RESELLER') {
      return {
        ...p,
        displayPrice: p.basePrice + resellerMargin,
        profit: resellerMargin
      };
    }
    return {
      ...p,
      displayPrice: p.price,
      profit: 0
    };
  });

  const currentList = getStepZeroList();

  return (
    <Dialog open={true} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-2xl p-0 overflow-hidden bg-[#0A0A0B] border-white/10 rounded-[3rem] shadow-[0_32px_64px_-12px_rgba(0,0,0,0.8)] focus:outline-none animate-in zoom-in-95 duration-300">
        <DialogHeader className={cn("p-10 text-white relative overflow-hidden transition-colors duration-500", selectedProvider?.color || "bg-primary")}>
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-3xl -translate-y-16 translate-x-16" />
          <div className="flex items-center justify-between relative z-10 w-full">
            <div className="flex items-center gap-5">
              <div className="w-16 h-16 rounded-[1.5rem] bg-white/20 flex items-center justify-center backdrop-blur-md shadow-2xl transition-transform group-hover:scale-110">
                {category === 'game' ? <Gamepad2 size={32} /> : 
                 category === 'data' ? <Globe size={32} /> :
                 category === 'ewallet' ? <Wallet size={32} /> :
                 category === 'pln' ? <Zap size={32} /> : <Smartphone size={32} />}
              </div>
              <div>
                <DialogTitle className="text-3xl font-black uppercase tracking-tight">
                  {selectedProvider ? selectedProvider.name : category.replace('_', ' ').toUpperCase()}
                </DialogTitle>
                <div className="flex items-center gap-2 mt-1.5">
                  <p className="text-[11px] font-black opacity-70 uppercase tracking-[0.3em]">Langkah {step + 1}</p>
                  {userRole === 'RESELLER' && (
                    <Badge className="bg-emerald-500 text-white border-none px-2 py-0 text-[8px] font-black">MODE RESELLER AKTIF</Badge>
                  )}
                </div>
              </div>
            </div>
            <button onClick={onClose} className="text-white/50 hover:text-white transition-all active:scale-90 focus:outline-none">
              <X size={32} />
            </button>
          </div>
        </DialogHeader>

        <div className="p-10 space-y-8 max-h-[70vh] overflow-y-auto no-scrollbar bg-black/20">
          
          {step === 0 && needsProviderSelection && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-6 duration-500">
              <label className="text-[11px] font-black text-slate-500 uppercase tracking-[0.4em] ml-2">
                PILIH LAYANAN TERSEDIA
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {currentList.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => { setSelectedProvider(item); setStep(1); }}
                    className={cn(
                      "p-6 rounded-[2rem] border-2 transition-all flex flex-col items-center gap-4 group active:scale-95 relative overflow-hidden",
                      selectedProvider?.id === item.id ? "bg-white/10 border-white/40" : "bg-white/5 border-white/5 hover:border-white/20"
                    )}
                  >
                    <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center text-white transition-all shadow-lg group-hover:scale-110 group-hover:rotate-6", item.color)}>
                      {React.cloneElement(item.icon as React.ReactElement, { size: 28 })}
                    </div>
                    <span className="text-[10px] font-black uppercase tracking-widest text-center leading-tight text-white/80 group-hover:text-white">{item.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-6 duration-500">
              <div className="space-y-4">
                <label className="text-[11px] font-black text-slate-500 uppercase tracking-[0.4em] ml-2 text-center block">
                  {selectedProvider ? `MASUKKAN ${selectedProvider.hint}` : 'NOMOR TUJUAN / ID PELANGGAN'}
                </label>
                <div className="relative">
                  <Input 
                    value={target} 
                    onChange={(e) => setTarget(e.target.value)} 
                    placeholder={selectedProvider ? `Contoh: ${selectedProvider.hint}` : "Contoh: 08123456789"} 
                    className="h-24 rounded-[2rem] bg-white/5 border-white/10 text-3xl font-black text-white focus:ring-4 focus:ring-primary/20 transition-all px-8 placeholder:text-white/5 text-center" 
                  />
                  {customerName && (
                    <div className="absolute right-6 top-1/2 -translate-y-1/2 flex items-center gap-2 text-[10px] font-black text-emerald-400 bg-emerald-500/10 px-5 py-2.5 rounded-full border border-emerald-500/20 backdrop-blur-md">
                      <UserCheck size={14} /> {customerName}
                    </div>
                  )}
                  {loadingName && (
                    <div className="absolute right-8 top-1/2 -translate-y-1/2">
                      <Loader2 className="animate-spin text-primary" size={24} />
                    </div>
                  )}
                </div>
              </div>
              <Button 
                onClick={handleNext} 
                disabled={target.length < 5} 
                className={cn("w-full h-24 rounded-[2.5rem] text-white font-black text-lg uppercase tracking-[0.3em] shadow-2xl active:scale-[0.98] transition-all gap-4 border-none", selectedProvider?.color || "bg-primary")}
              >
                PILIH NOMINAL <ArrowRight size={24} />
              </Button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-6 duration-500">
              <div className="grid grid-cols-2 gap-4">
                {productsToDisplay.map(p => (
                  <button 
                    key={p.id} 
                    onClick={() => setSelectedProduct(p)} 
                    className={cn(
                      "p-8 rounded-[2.5rem] border-2 transition-all text-left flex flex-col justify-between h-44 relative overflow-hidden group active:scale-95", 
                      selectedProduct?.id === p.id ? "bg-white/10 border-white/30 shadow-2xl" : "bg-white/5 border-white/5 hover:border-white/20"
                    )}
                  >
                    <div className="text-3xl font-black text-white tracking-tighter">{p.label}</div>
                    <div className="space-y-1">
                      {userRole === 'RESELLER' ? (
                        <>
                          <div className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Modal: Rp {p.basePrice.toLocaleString()}</div>
                          <div className="flex items-center justify-between">
                             <div className="text-sm font-black text-primary">Rp {p.displayPrice.toLocaleString()}</div>
                             <Badge className="bg-emerald-500/10 text-emerald-400 border-none text-[8px] font-black">+Rp {p.profit.toLocaleString()}</Badge>
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="text-[9px] font-black text-emerald-400 uppercase tracking-widest">+{p.points} Poin Referral</div>
                          <div className="text-sm font-black text-primary">Rp {p.displayPrice.toLocaleString()}</div>
                        </>
                      )}
                    </div>
                    {selectedProduct?.id === p.id && (
                      <div className="absolute top-6 right-6 text-primary animate-in zoom-in-50">
                        <Check size={28} />
                      </div>
                    )}
                  </button>
                ))}
              </div>
              
              <div className="p-6 rounded-[2rem] bg-white/5 border border-white/10 flex items-center gap-6 group hover:border-primary/50 transition-all">
                <TicketPercent size={32} className="text-primary group-hover:scale-110 transition-transform" />
                <div className="flex-1">
                   <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Punya Kode Diskon? (Opsional)</p>
                   <Input 
                      value={discountCode}
                      onChange={(e) => setDiscountCode(e.target.value)}
                      placeholder="MASUKKAN KODE" 
                      className="bg-transparent border-none p-0 h-auto text-sm font-bold focus-visible:ring-0 uppercase placeholder:text-white/10" 
                   />
                </div>
              </div>

              <Button 
                onClick={handleNext} 
                disabled={!selectedProduct || isProcessing} 
                className={cn("w-full h-24 rounded-[2.5rem] text-white font-black text-lg uppercase tracking-[0.3em] shadow-2xl active:scale-[0.98] transition-all border-none", selectedProvider?.color || "bg-primary")}
              >
                {isProcessing ? <Loader2 className="animate-spin" size={28} /> : "BAYAR SEKARANG"}
              </Button>
            </div>
          )}

          {step === 3 && (
            <div className="text-center space-y-10 animate-in zoom-in-95 duration-700">
               <div className="bg-white/5 p-10 rounded-[4rem] border border-white/10 space-y-8 backdrop-blur-3xl">
                  <div className="relative w-64 h-64 mx-auto bg-white rounded-[2.5rem] p-6 shadow-[0_32px_64px_-12px_rgba(255,255,255,0.2)]">
                    <Image src="https://i.imgur.com/IvVcoBz.png" alt="QRIS" fill className="object-contain p-4" />
                  </div>
                  <div className="bg-white/10 p-8 rounded-[2rem] border border-white/20">
                    <p className="text-[11px] font-black text-slate-500 uppercase tracking-[0.4em] mb-2">TOTAL PEMBAYARAN</p>
                    <p className="text-5xl font-black text-white tracking-tighter">Rp {selectedProduct?.displayPrice.toLocaleString()}</p>
                    {userRole === 'RESELLER' ? (
                       <div className="mt-4 flex items-center justify-center gap-2 text-[10px] font-black text-primary uppercase tracking-widest">
                          <TrendingUp size={14}/> KEUNTUNGAN ANDA: Rp {selectedProduct?.profit.toLocaleString()}
                       </div>
                    ) : (
                      <div className="mt-4 flex items-center justify-center gap-2 text-[10px] font-black text-emerald-400 uppercase tracking-widest">
                         <Coins size={14}/> ANDA AKAN MENDAPATKAN {selectedProduct?.points} POIN
                      </div>
                    )}
                  </div>
               </div>
               <div className="space-y-6">
                  <input 
                    type="file" 
                    accept="image/*" 
                    ref={fileInputRef} 
                    className="hidden" 
                    onChange={handleFileChange} 
                  />
                  <Button 
                    onClick={() => fileInputRef.current?.click()} 
                    disabled={uploading} 
                    className="w-full h-24 rounded-[2.5rem] bg-white text-black hover:bg-slate-100 font-black text-base uppercase tracking-[0.2em] shadow-2xl shadow-white/10 active:scale-[0.98] transition-all gap-4 border-none"
                  >
                    <ImageIcon size={28}/> {uploading ? "MENGIRIM BUKTI..." : "UNGGAH BUKTI BAYAR"}
                  </Button>
                  <div className="flex items-center justify-center gap-4 text-[11px] font-black text-emerald-400 uppercase tracking-widest bg-emerald-500/5 py-4 rounded-full border border-emerald-500/10">
                    <ShieldCheck size={18}/> SISTEM KEAMANAN TERENKRIPSI AKTIF
                  </div>
               </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
