
/**
 * @fileOverview Simulasi integrasi API VIP Reseller
 */

export interface DeliveryResponse {
  success: boolean;
  message: string;
  sn?: string; // Serial Number
}

export async function sendProductToCustomer(
  apiKey: string,
  transaction: { target: string; product: string; amount: number }
): Promise<DeliveryResponse> {
  // Simulasi hit API ke provider PPOB
  console.log(`Mengirim pesanan via VIP Reseller dengan API Key: ${apiKey.substring(0, 4)}****`);
  
  // Simulasi delay network
  await new Promise(resolve => setTimeout(resolve, 2000));

  if (!apiKey || apiKey.length < 5) {
    return { success: false, message: 'API Key tidak valid atau belum diatur.' };
  }

  // Simulasi sukses
  return {
    success: true,
    message: 'Produk berhasil dikirim otomatis oleh sistem.',
    sn: 'SN' + Math.random().toString().substring(2, 12).toUpperCase()
  };
}
