
"use client"
import React, { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { 
  Activity, ShoppingCart, Settings, LogOut, 
  MessageSquare, User, Bell, PackageSearch,
  Check, X, Eye, TrendingUp, ArrowUpRight,
  ShieldCheck, MoreHorizontal, UserCheck, Banknote,
  Search, Calendar, Info, Loader2, ImageIcon, ScanLine, Send,
  Users, CreditCard, BarChart3, TrendingDown, Gift, Clock, AlertTriangle, Paperclip
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import Image from 'next/image';

interface ChatMessage {
  role: 'admin' | 'user';
  text?: string;
  image?: string;
  time: string;
}

export default function AdminDashboard() {
  const [mounted, setMounted] = useState(false);
  const [authorized, setAuthorized] = useState(false);
  const router = useRouter();
  const { toast } = useToast();
  
  const [transactions, setTransactions] = useState([
    { id: 'TX-8821', target: '08123456789', product: 'Pulsa 10.000', amount: 11500, costPrice: 10200, status: 'WAITING', date: 'Baru saja', proofUrl: 'https://i.imgur.com/IvVcoBz.png', method: 'QRIS' },
    { id: 'TX-8822', target: '08571234455', product: 'DANA 50.000', amount: 52000, costPrice: 50500, status: 'PROSES', date: '5 menit lalu', proofUrl: 'https://i.imgur.com/IvVcoBz.png', method: 'QRIS' },
    { id: 'TX-8823', target: '123456789', product: 'Top Up ML 86 DM', amount: 22000, costPrice: 20100, status: 'WAITING', date: '10 menit lalu', proofUrl: 'https://i.imgur.com/IvVcoBz.png', method: 'QRIS' },
  ]);
  const [memberRequests, setMemberRequests] = useState([
    { id: 'REQ-01', user: 'Andi Wijaya', type: 'RESELLER', status: 'PENDING', date: '1 jam lalu' },
    { id: 'REQ-02', user: 'Siti Aminah', type: 'AFFILIATE', status: 'PENDING', date: '2 jam lalu' },
  ]);
  
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { role: 'user', text: 'Halo Admin, saya baru saja upload bukti bayar untuk transaksi #TX-8821. Tolong segera di cek ya, terima kasih.', time: '10:05' },
    { role: 'user', image: 'https://i.imgur.com/IvVcoBz.png', time: '10:06' }
  ]);
  const [selectedTx, setSelectedTx] = useState<any>(null);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [replyText, setReplyText] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setMounted(true);
    const session = localStorage.getItem('admin_session');
    if (!session) {
      router.push('/admin/login');
    } else {
      setAuthorized(true);
    }
  }, [router]);

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages, isChatOpen]);

  const handleLogout = () => {
    localStorage.removeItem('admin_session');
    toast({
      title: "Berhasil Keluar",
      description: "Sesi admin telah diakhiri secara aman.",
    });
    router.push('/');
  };

  const updateOrderStatus = (id: string, newStatus: string) => {
    setTransactions(prev => prev.map(tx => tx.id === id ? { ...tx, status: newStatus } : tx));
    toast({
      title: "Status Diperbarui",
      description: `Pesanan ${id} kini berstatus ${newStatus}.`,
    });
    if (selectedTx?.id === id) setSelectedTx(null);
  };

  const handleReplyChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim()) return;
    
    const newMessage: ChatMessage = {
      role: 'admin',
      text: replyText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    
    setChatMessages(prev => [...prev, newMessage]);
    toast({ 
      title: "Pesan Terkirim", 
      description: "Balasan Anda telah ditampilkan di chat pelanggan." 
    });
    setReplyText('');
  };

  const handleAdminImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64Image = event.target?.result as string;
        const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        setChatMessages(prev => [...prev, { role: 'admin', image: base64Image, time }]);
        toast({ title: "Gambar Terkirim", description: "Foto berhasil dikirim ke pelanggan." });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleApproveMember = (id: string, name: string) => {
    setMemberRequests(prev => prev.filter(req => req.id !== id));
    toast({ title: "Pendaftaran Disetujui", description: `${name} resmi menjadi member.` });
  };

  const handleRejectMember = (id: string) => {
    setMemberRequests(prev => prev.filter(req => req.id !== id));
    toast({ variant: "destructive", title: "Ditolak", description: "Permintaan member telah dihapus." });
  };

  const formatCurrency = (val: number) => {
    if (!mounted) return `Rp ${val}`;
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(val);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'SUKSES': return <Badge className="bg-emerald-500/10 text-emerald-500 border-none px-3 py-1 rounded-lg text-[9px] font-black">SUKSES</Badge>;
      case 'PROSES': return <Badge className="bg-blue-500/10 text-blue-500 border-none px-3 py-1 rounded-lg text-[9px] font-black">PROSES</Badge>;
      case 'BATAL': return <Badge className="bg-rose-500/10 text-rose-500 border-none px-3 py-1 rounded-lg text-[9px] font-black">BATAL</Badge>;
      default: return <Badge className="bg-amber-500/10 text-amber-500 border-none px-3 py-1 rounded-lg text-[9px] font-black">WAITING</Badge>;
    }
  };

  if (!mounted || !authorized) return (
    <div className="min-h-screen bg-[#0A0A0B] flex items-center justify-center">
      <Loader2 className="animate-spin text-primary w-12 h-12" />
    </div>
  );

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-white flex overflow-hidden">
      {/* Sidebar Desktop */}
      <aside className="w-72 border-r border-white/5 hidden lg:flex flex-col fixed inset-y-0 z-50 bg-[#0A0A0B]">
        <div className="p-8 flex items-center gap-3">
          <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white font-black">AP</div>
          <div className="flex flex-col">
            <span className="font-black text-lg">ADMIN</span>
            <span className="text-[10px] text-primary font-bold uppercase tracking-widest">Panel Kontrol</span>
          </div>
        </div>
        <nav className="flex-1 px-4 space-y-2 mt-4">
          <Button variant="ghost" className="w-full justify-start gap-4 rounded-2xl h-12 bg-white/5 text-primary">
            <Activity size={18}/> Dashboard
          </Button>
          <Button onClick={() => setIsChatOpen(true)} variant="ghost" className="w-full justify-start gap-4 rounded-2xl h-12 text-slate-400 hover:bg-white/5">
            <MessageSquare size={18}/> Live Chat
          </Button>
          <Button variant="ghost" className="w-full justify-start gap-4 rounded-2xl h-12 text-slate-400 hover:bg-white/5">
            <Users size={18}/> Data Member
          </Button>
          <Button variant="ghost" className="w-full justify-start gap-4 rounded-2xl h-12 text-slate-400 hover:bg-white/5">
            <BarChart3 size={18}/> Keuangan
          </Button>
        </nav>
        <div className="p-8 border-t border-white/5">
          <Button onClick={handleLogout} variant="ghost" className="w-full justify-start gap-4 text-rose-500 hover:bg-rose-500/5">
            <LogOut size={18}/> Keluar
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 lg:ml-72 p-8 space-y-8 overflow-y-auto h-screen no-scrollbar">
        <header className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-black tracking-tight text-white uppercase italic">WORKSPACE OWNER</h1>
            <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.2em] mt-1">Sistem PPOB Otomatis v2.5 • ONLINE</p>
          </div>
          <div className="flex items-center gap-4">
            <Button onClick={() => setIsChatOpen(true)} variant="ghost" className="relative w-12 h-12 rounded-2xl bg-white/5 hover:bg-primary/20 hover:text-primary transition-all">
              <MessageSquare size={20} />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-primary text-white text-[8px] font-black flex items-center justify-center rounded-full animate-pulse">1</span>
            </Button>
            <div className="w-10 h-10 rounded-full border-2 border-primary p-0.5 overflow-hidden">
               <Image src="https://picsum.photos/seed/admin/100/100" alt="Admin" width={40} height={40} className="rounded-full object-cover" />
            </div>
          </div>
        </header>

        {/* Statistik Ringkas */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
           {[
             { label: "Pemasukan", val: formatCurrency(12400000), icon: <TrendingUp size={16}/>, color: "text-emerald-500" },
             { label: "Pengeluaran", val: formatCurrency(8200000), icon: <TrendingDown size={16}/>, color: "text-rose-500" },
             { label: "Laba Bersih", val: formatCurrency(4200000), icon: <BarChart3 size={16}/>, color: "text-primary" },
             { label: "Poin Aktif", val: "15,400", icon: <Gift size={16}/>, color: "text-amber-500" }
           ].map((stat, i) => (
             <Card key={i} className="glass-card p-6 border-none rounded-3xl space-y-2">
                <div className={cn("w-8 h-8 rounded-xl bg-white/5 flex items-center justify-center", stat.color)}>{stat.icon}</div>
                <p className="text-xl font-black">{stat.val}</p>
                <p className="text-[9px] text-slate-500 font-bold uppercase tracking-widest">{stat.label}</p>
             </Card>
           ))}
        </div>

        {/* Tab Konten */}
        <Tabs defaultValue="orders" className="space-y-6">
          <TabsList className="bg-white/5 border border-white/10 p-1 rounded-2xl h-14 w-fit">
            <TabsTrigger value="orders" className="rounded-xl px-8 font-black text-[10px] uppercase tracking-widest">Antrian Pesanan</TabsTrigger>
            <TabsTrigger value="members" className="rounded-xl px-8 font-black text-[10px] uppercase tracking-widest">Verifikasi Member</TabsTrigger>
            <TabsTrigger value="finance" className="rounded-xl px-8 font-black text-[10px] uppercase tracking-widest">Laporan Laba</TabsTrigger>
          </TabsList>

          <TabsContent value="orders" className="space-y-3">
             {transactions.map(tx => (
               <Card key={tx.id} className="glass-card p-5 rounded-[2rem] flex items-center justify-between border-none hover:bg-white/[0.08] transition-all group">
                  <div className="flex items-center gap-4">
                     <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center text-primary group-hover:scale-110 transition-transform"><PackageSearch size={20}/></div>
                     <div>
                        <div className="flex items-center gap-2">
                           <p className="font-bold text-sm text-white">{tx.product}</p>
                           {getStatusBadge(tx.status)}
                        </div>
                        <p className="text-[9px] text-slate-500 font-black uppercase tracking-widest mt-0.5">{tx.target} • {tx.id}</p>
                     </div>
                  </div>
                  <div className="flex items-center gap-3">
                     <div className="hidden md:flex items-center gap-2 mr-4">
                        <Button onClick={() => updateOrderStatus(tx.id, 'SUKSES')} size="sm" className="bg-emerald-500 hover:bg-emerald-600 rounded-lg px-3 h-8 text-[8px] font-black uppercase">SUKSES</Button>
                        <Button onClick={() => updateOrderStatus(tx.id, 'PROSES')} size="sm" className="bg-blue-500 hover:bg-blue-600 rounded-lg px-3 h-8 text-[8px] font-black uppercase">PROSES</Button>
                        <Button onClick={() => updateOrderStatus(tx.id, 'BATAL')} size="sm" className="bg-rose-500 hover:bg-rose-600 rounded-lg px-3 h-8 text-[8px] font-black uppercase">BATAL</Button>
                     </div>
                     <Badge className="bg-white/10 text-white border-none px-4 py-1.5 rounded-xl text-[9px] font-black">{formatCurrency(tx.amount)}</Badge>
                     <Button variant="ghost" onClick={() => setSelectedTx(tx)} className="w-10 h-10 rounded-xl bg-white/5 hover:bg-white/10 active:scale-90 transition-all text-white"><Eye size={16}/></Button>
                  </div>
               </Card>
             ))}
          </TabsContent>

          <TabsContent value="members" className="space-y-3">
             {memberRequests.map(req => (
               <Card key={req.id} className="glass-card p-5 rounded-[2rem] flex items-center justify-between border-none">
                  <div className="flex items-center gap-4">
                     <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center text-amber-500"><UserCheck size={20}/></div>
                     <div>
                        <p className="font-bold text-sm text-white">{req.user}</p>
                        <p className="text-[9px] text-slate-500 font-black uppercase tracking-widest mt-0.5">{req.type} • {req.date}</p>
                     </div>
                  </div>
                  <div className="flex gap-2">
                     <Button onClick={() => handleApproveMember(req.id, req.user)} size="sm" className="bg-emerald-500 hover:bg-emerald-600 rounded-xl px-5 h-10 font-black text-[9px] uppercase active:scale-95 transition-all text-white">SETUJUI</Button>
                     <Button onClick={() => handleRejectMember(req.id)} variant="ghost" size="sm" className="bg-white/5 hover:bg-rose-500/10 hover:text-rose-500 rounded-xl px-5 h-10 font-black text-[9px] uppercase active:scale-95 transition-all text-white">TOLAK</Button>
                  </div>
               </Card>
             ))}
          </TabsContent>

          <TabsContent value="finance" className="space-y-6">
             <Card className="glass-card p-8 rounded-[2.5rem] border-none">
                <h3 className="font-black text-[10px] uppercase tracking-[0.3em] text-primary mb-6">Produk Terlaris Minggu Ini</h3>
                <div className="space-y-3">
                   {[
                     { name: "Pulsa Telkomsel 10rb", sales: 1520, profit: formatCurrency(1500000) },
                     { name: "Token PLN 50rb", sales: 840, profit: formatCurrency(800000) },
                     { name: "DANA Top Up 100rb", sales: 610, profit: formatCurrency(600000) }
                   ].map((p, i) => (
                     <div key={i} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl hover:bg-white/10 transition-colors cursor-default text-white">
                        <span className="font-bold text-xs">{p.name}</span>
                        <div className="text-right">
                           <p className="font-black text-xs">{p.sales} Order</p>
                           <p className="text-[9px] text-primary font-black uppercase tracking-widest">{p.profit}</p>
                        </div>
                     </div>
                   ))}
                </div>
             </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Dialog Chat Admin */}
      <Dialog open={isChatOpen} onOpenChange={setIsChatOpen}>
        <DialogContent className="max-w-md p-0 bg-[#0A0A0B] border-white/10 rounded-[3rem] overflow-hidden focus:outline-none shadow-[0_32px_64px_-12px_rgba(0,0,0,0.8)]">
          <div className="bg-primary p-6 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center border border-white/30 backdrop-blur-md">
                <MessageSquare size={20} />
              </div>
              <div>
                <DialogTitle className="font-black text-xs uppercase tracking-[0.2em]">Live Chat Support</DialogTitle>
                <p className="text-[8px] opacity-70 font-bold uppercase tracking-widest mt-0.5">PELANGGAN SEDANG MENUNGGU</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={() => setIsChatOpen(false)} className="text-white/50 hover:text-white rounded-full"><X size={20}/></Button>
          </div>
          <div className="h-[400px] p-6 overflow-y-auto space-y-4 bg-black/40 no-scrollbar flex flex-col">
            {chatMessages.map((msg, i) => (
              <div key={i} className={cn("flex gap-3 max-w-[85%]", msg.role === 'admin' ? "ml-auto flex-row-reverse" : "")}>
                 <div className={cn("w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-white", msg.role === 'admin' ? "bg-primary" : "bg-slate-800")}>
                    <User size={14}/>
                 </div>
                 <div className="flex flex-col gap-1">
                    <div className={cn("p-4 rounded-2xl text-[10px] font-bold leading-relaxed shadow-sm", msg.role === 'admin' ? "bg-primary text-white rounded-tr-none" : "bg-white/5 text-slate-300 rounded-tl-none")}>
                      {msg.image ? (
                        <div className="relative w-40 h-56 rounded-xl overflow-hidden mb-1">
                           <Image src={msg.image} alt="Chat content" fill className="object-cover" />
                        </div>
                      ) : (
                        msg.text
                      )}
                    </div>
                    <span className="text-[8px] text-slate-600 font-bold px-1 uppercase">{msg.time}</span>
                 </div>
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>
          <form onSubmit={handleReplyChat} className="p-6 border-t border-white/5 flex gap-3 bg-white/[0.02] items-center">
             <input 
                type="file" 
                accept="image/*" 
                ref={fileInputRef} 
                className="hidden" 
                onChange={handleAdminImageUpload} 
             />
             <Button 
                type="button" 
                variant="ghost" 
                size="icon" 
                onClick={() => fileInputRef.current?.click()}
                className="rounded-2xl h-14 w-14 shrink-0 text-slate-500 hover:text-primary hover:bg-primary/5 transition-all"
             >
                <ImageIcon size={24} />
             </Button>
             <Input 
                value={replyText} 
                onChange={(e) => setReplyText(e.target.value)} 
                placeholder="Tulis balasan..." 
                className="rounded-2xl bg-white/5 border-white/10 h-14 text-xs font-bold text-white focus:ring-primary/20" 
             />
             <Button type="submit" size="icon" className="h-14 w-14 rounded-2xl bg-primary hover:bg-primary/90 active:scale-90 transition-all shrink-0 shadow-lg shadow-primary/20"><Send size={18}/></Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* Dialog Detail Transaksi & Verifikasi Gambar */}
      <Dialog open={!!selectedTx} onOpenChange={() => setSelectedTx(null)}>
        <DialogContent className="max-w-5xl p-0 bg-[#0A0A0B] border-white/10 rounded-[2.5rem] overflow-hidden focus:outline-none shadow-[0_64px_128px_-12px_rgba(59,130,246,0.3)]">
           <div className="grid md:grid-cols-2">
              {/* Bagian Kiri: Gambar Bukti Bayar */}
              <div className="bg-black/60 min-h-[500px] flex items-center justify-center relative border-r border-white/5 p-8">
                 {selectedTx?.proofUrl ? (
                   <div className="relative w-full h-full flex flex-col gap-4">
                     <p className="text-[10px] font-black text-primary uppercase tracking-[0.4em] text-center bg-primary/10 py-3 rounded-xl border border-primary/20">BUKTI BAYAR PELANGGAN</p>
                     <div className="relative flex-1 rounded-3xl overflow-hidden border-2 border-white/10">
                        <Image src={selectedTx.proofUrl} alt="Bukti Transfer" fill className="object-contain" />
                     </div>
                   </div>
                 ) : (
                   <div className="flex flex-col items-center gap-4 text-white/20">
                      <ImageIcon size={64} />
                      <p className="font-black uppercase tracking-tighter text-2xl">TIDAK ADA BUKTI</p>
                   </div>
                 )}
              </div>

              {/* Bagian Kanan: Detail & Aksi */}
              <div className="p-10 space-y-6 flex flex-col justify-center bg-[#0A0A0B]">
                 <div>
                    <div className="flex items-center gap-3 mb-2">
                       <DialogTitle className="text-3xl font-black uppercase tracking-tight text-white">VERIFIKASI TRANSAKSI</DialogTitle>
                       {getStatusBadge(selectedTx?.status)}
                    </div>
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">ORDER ID: {selectedTx?.id} • {selectedTx?.date}</p>
                 </div>
                 
                 <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
                       <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">PRODUK YANG DIBELI</p>
                       <p className="text-sm font-bold text-white">{selectedTx?.product}</p>
                    </div>
                    <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
                       <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">METODE PEMBAYARAN</p>
                       <p className="text-sm font-bold text-white uppercase">{selectedTx?.method}</p>
                    </div>
                    <div className="p-4 rounded-2xl bg-white/10 border border-primary/30 col-span-2">
                       <p className="text-[8px] font-black text-primary uppercase tracking-widest mb-1">NOMOR TUJUAN PENGIRIMAN</p>
                       <p className="text-2xl font-black text-white tracking-widest">{selectedTx?.target}</p>
                    </div>
                 </div>

                 {/* Analisa Keuntungan */}
                 <div className="p-6 rounded-[2rem] bg-white/5 border border-white/10 space-y-3 text-xs">
                    <div className="flex justify-between font-bold text-slate-400"><span>Harga Modal Supplier</span><span>{formatCurrency(selectedTx?.costPrice || 0)}</span></div>
                    <div className="flex justify-between font-bold text-slate-400"><span>Harga Jual ke Toko</span><span>{formatCurrency(selectedTx?.amount || 0)}</span></div>
                    <div className="flex justify-between font-black border-t border-white/5 pt-3"><span>Estimasi Laba Bersih</span><span className="text-emerald-400 text-xl">{formatCurrency((selectedTx?.amount || 0) - (selectedTx?.costPrice || 0))}</span></div>
                 </div>

                 <div className="space-y-3 pt-2">
                    <div className="grid grid-cols-2 gap-3">
                       <Button onClick={() => updateOrderStatus(selectedTx.id, 'SUKSES')} className="h-16 rounded-2xl bg-emerald-500 hover:bg-emerald-600 font-black uppercase text-[10px] tracking-widest text-white active:scale-95 transition-all">KONFIRMASI SUKSES</Button>
                       <Button onClick={() => updateOrderStatus(selectedTx.id, 'PROSES')} className="h-16 rounded-2xl bg-blue-500 hover:bg-blue-600 font-black uppercase text-[10px] tracking-widest text-white active:scale-95 transition-all">UPDATE PROSES</Button>
                    </div>
                    <Button onClick={() => updateOrderStatus(selectedTx.id, 'BATAL')} variant="outline" className="w-full h-16 rounded-2xl border-rose-500 text-rose-500 hover:bg-rose-500/10 font-black uppercase text-[10px] tracking-widest active:scale-95 transition-all">BATALKAN & TOLAK</Button>
                 </div>
                 
                 <p className="text-[9px] text-slate-500 italic text-center font-medium opacity-50">* Verifikasi manual sangat disarankan untuk menjaga keamanan sistem.</p>
              </div>
           </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
