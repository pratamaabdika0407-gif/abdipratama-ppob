"use client"
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Smartphone, Lock, User, AlertCircle } from 'lucide-react';
import Link from 'next/link';
import { useToast } from '@/hooks/use-toast';

export default function AdminLogin() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const router = useRouter();
  const { toast } = useToast();

  /**
   * Kredensial Admin Baru
   * Username: admin
   * Password: Admin@AbdiPratama2025
   */
  const SECURE_USER = "admin";
  const SECURE_PASS = "Admin@AbdiPratama2025";

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(false);

    // Simulasi proses otentikasi
    setTimeout(() => {
      if (username === SECURE_USER && password === SECURE_PASS) {
        localStorage.setItem('admin_session', 'active_' + Date.now());
        toast({
          title: "Login Berhasil",
          description: "Selamat datang kembali di panel kontrol Abdi Pratama.",
        });
        router.push('/admin/dashboard');
      } else {
        setError(true);
        toast({
          variant: "destructive",
          title: "Akses Ditolak",
          description: "Username atau password salah.",
        });
        setLoading(false);
      }
    }, 1200);
  };

  return (
    <div className="min-h-svh bg-slate-50 flex flex-col items-center justify-center p-4">
      <Link href="/" className="flex items-center gap-2 mb-8 group">
        <div className="rounded-lg bg-primary p-1.5 text-primary-foreground transition-transform group-hover:scale-110">
          <Smartphone size={24} strokeWidth={2.5} />
        </div>
        <span className="font-headline text-xl font-bold tracking-tight text-primary">
          Abdi Pratama <span className="text-slate-900">PPOB</span>
        </span>
      </Link>
      
      <Card className="w-full max-w-md shadow-2xl border-none ring-1 ring-slate-200 rounded-[2rem] overflow-hidden">
        <CardHeader className="text-center space-y-1 bg-slate-950 text-white p-8">
          <CardTitle className="text-2xl font-black uppercase tracking-tighter">Restricted Access</CardTitle>
          <CardDescription className="text-slate-400 font-bold">Silakan masukkan kredensial admin Anda.</CardDescription>
        </CardHeader>
        <form onSubmit={handleLogin}>
          <CardContent className="space-y-6 p-8">
            {error && (
              <div className="bg-destructive/10 text-destructive p-4 rounded-2xl text-xs flex items-center gap-3 animate-pulse border border-destructive/20 font-bold">
                <AlertCircle size={16} /> Kredensial tidak valid. Silakan coba lagi.
              </div>
            )}
            <div className="space-y-3">
              <Label htmlFor="username" className="font-black text-[10px] uppercase tracking-widest text-slate-400">Username</Label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-300" />
                <Input 
                  id="username" 
                  placeholder="admin" 
                  className="pl-12 h-14 rounded-2xl bg-slate-50 border-slate-100 focus:bg-white transition-all font-bold" 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  autoComplete="off"
                />
              </div>
            </div>
            <div className="space-y-3">
              <Label htmlFor="password" className="font-black text-[10px] uppercase tracking-widest text-slate-400">Password</Label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-300" />
                <Input 
                  id="password" 
                  type="password" 
                  placeholder="••••••••••••"
                  className="pl-12 h-14 rounded-2xl bg-slate-50 border-slate-100 focus:bg-white transition-all font-bold" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
            </div>
          </CardContent>
          <CardFooter className="p-8 pt-0">
            <Button type="submit" className="w-full h-16 rounded-2xl font-black text-lg shadow-xl shadow-primary/20 transition-all active:scale-95" disabled={loading}>
              {loading ? 'MEMVERIFIKASI...' : 'MASUK PANEL ADMIN'}
            </Button>
          </CardFooter>
        </form>
      </Card>
      
      <div className="mt-8 text-center space-y-1">
        <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-black">Encrypted Connection Active</p>
        <p className="text-[10px] text-muted-foreground font-bold">© Abdi Pratama Secure System v2.0</p>
      </div>
    </div>
  );
}
