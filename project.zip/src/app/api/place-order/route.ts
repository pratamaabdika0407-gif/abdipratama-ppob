
import { NextResponse } from 'next/server';
import crypto from 'crypto';
import axios from 'axios';

const API_ID = "suoAtR3x";
const API_KEY = "qQYwnNCiASXhVOUkoVK21pQ2Ox2h3jFLMyu2NS9lFbtfRR2qTVY7RW6Xd1qljsq";
const API_URL = "https://vip-reseller.co.id/api/prepaid";

export async function POST(req: Request) {
  try {
    const { targetNumber, productCode, orderId } = await req.json();

    // Generate Signature: MD5(API_ID + API_KEY + orderId)
    const sign = crypto.createHash('md5').update(API_ID + API_KEY + orderId).digest('hex');

    const params = new URLSearchParams();
    params.append('key', API_KEY);
    params.append('sign', sign);
    params.append('type', 'order');
    params.append('service', productCode);
    params.append('target', targetNumber);
    params.append('ref_id', orderId);

    // Call VIP Reseller API
    const response = await axios.post(API_URL, params);

    // Di sini Anda biasanya mencatat ke Firestore koleksi 'orders'
    // Untuk demo, kita langsung kembalikan respon
    return NextResponse.json({
      success: true,
      data: response.data,
      message: "Order has been forwarded to supplier"
    });

  } catch (error: any) {
    console.error("Order error:", error);
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}
