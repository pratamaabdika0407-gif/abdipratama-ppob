import { config } from 'dotenv';
config();

import '@/ai/flows/payment-proof-validation.ts';
import '@/ai/flows/customer-inquiry.ts';
import '@/ai/flows/live-chat.ts';
