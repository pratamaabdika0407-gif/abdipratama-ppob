'use server';
/**
 * @fileOverview An AI agent for validating payment proofs.
 *
 * - validatePaymentProof - A function that handles the payment proof validation process.
 * - PaymentProofValidationInput - The input type for the validatePaymentProof function.
 * - PaymentProofValidationOutput - The return type for the validatePaymentProof function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const PaymentProofValidationInputSchema = z.object({
  paymentProofImageUri: z
    .string()
    .describe(
      "A payment proof image, provided as a public URL or a Base64 data URI."
    ),
  expectedAmount: z.number().describe('The expected transaction amount in IDR.'),
  transactionId: z.string().describe('The unique ID of the transaction to verify.'),
  merchantName: z
    .string()
    .describe('The name of the merchant expected on the payment proof (e.g., Abdi Pratama PPOB).'),
  customerName: z.string().optional().describe('Optional: The name of the customer for context.'),
});
export type PaymentProofValidationInput = z.infer<typeof PaymentProofValidationInputSchema>;

const PaymentProofValidationOutputSchema = z.object({
  isMatch: z
    .boolean()
    .describe('True if the payment proof likely matches the transaction details, false otherwise.'),
  confidenceScore: z
    .number()
    .min(0)
    .max(100)
    .describe('A confidence score (0-100) for the validation.'),
  extractedAmount: z.number().describe('The payment amount extracted from the proof.'),
  extractedMerchant: z.string().describe('The merchant name extracted from the proof.'),
  extractedTransactionId: z
    .string()
    .optional()
    .describe('The transaction ID or reference number extracted from the proof, if available.'),
  suggestedStatus: z
    .enum(['APPROVED', 'REJECTED', 'PENDING_MANUAL_REVIEW'])
    .describe(
      "Suggested status for the transaction: 'APPROVED', 'REJECTED', or 'PENDING_MANUAL_REVIEW'."
    ),
  reason: z.string().describe('Explanation for the suggested status.'),
});
export type PaymentProofValidationOutput = z.infer<typeof PaymentProofValidationOutputSchema>;

export async function validatePaymentProof(
  input: PaymentProofValidationInput
): Promise<PaymentProofValidationOutput> {
  return paymentProofValidationFlow(input);
}

const paymentProofValidationPrompt = ai.definePrompt({
  name: 'paymentProofValidationPrompt',
  input: { schema: PaymentProofValidationInputSchema },
  output: { schema: PaymentProofValidationOutputSchema },
  prompt: `You are an AI assistant specialized in validating payment proofs for online transactions.
Your task is to analyze an uploaded payment proof image and compare it against provided transaction details.

Transaction Details:
- Expected Amount: Rp {{{expectedAmount}}}
- Transaction ID: {{{transactionId}}}
- Expected Merchant: {{{merchantName}}}
{{#if customerName}}- Customer Name: {{{customerName}}}{{/if}}

Instructions:
1. Carefully examine the payment proof image provided.
2. Extract the payment amount, merchant name, and any transaction ID or reference number visible in the image.
3. Compare the extracted information with the 'Transaction Details' provided above.
4. Determine if the payment proof is valid for this specific transaction.
5. Provide a clear reason for your decision.

Payment Proof Image: {{media url=paymentProofImageUri}}`,
});

const paymentProofValidationFlow = ai.defineFlow(
  {
    name: 'paymentProofValidationFlow',
    inputSchema: PaymentProofValidationInputSchema,
    outputSchema: PaymentProofValidationOutputSchema,
  },
  async (input) => {
    try {
      const { output } = await paymentProofValidationPrompt(input);
      if (!output) throw new Error("AI failed to generate a response.");
      return output;
    } catch (err) {
      console.error("Payment Validation Flow Error:", err);
      // Fallback response to avoid crash
      return {
        isMatch: false,
        confidenceScore: 0,
        extractedAmount: 0,
        extractedMerchant: "Unknown",
        suggestedStatus: 'PENDING_MANUAL_REVIEW',
        reason: "Sistem AI sedang sibuk atau gambar tidak dapat diakses. Mohon verifikasi secara manual.",
      };
    }
  }
);
