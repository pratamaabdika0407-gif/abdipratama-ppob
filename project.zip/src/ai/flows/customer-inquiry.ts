'use server';
/**
 * @fileOverview An AI-powered flow to simulate customer name inquiry based on phone number or ID.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const CustomerInquiryInputSchema = z.object({
  targetNumber: z.string().describe('The phone number or customer ID to check.'),
  serviceType: z.string().describe('The type of service (e.g., pulsa, pln, ewallet).'),
});

const CustomerInquiryOutputSchema = z.object({
  customerName: z.string().describe('The detected name of the customer.'),
  provider: z.string().describe('The detected provider (e.g., Telkomsel, PLN, DANA).'),
  isValid: z.boolean().describe('Whether the number is valid and active.'),
});

export async function checkCustomerName(input: z.infer<typeof CustomerInquiryInputSchema>) {
  return customerInquiryFlow(input);
}

const customerInquiryFlow = ai.defineFlow(
  {
    name: 'customerInquiryFlow',
    inputSchema: CustomerInquiryInputSchema,
    outputSchema: CustomerInquiryOutputSchema,
  },
  async (input) => {
    // Simulated logic to "detect" name based on number patterns for demo purposes
    const num = input.targetNumber;
    let name = "PELANGGAN SETIA";
    let provider = "UNKNOWN";

    if (num.startsWith('0812') || num.startsWith('0813')) {
      provider = "Telkomsel";
      name = "Budi Santoso";
    } else if (num.startsWith('0857') || num.startsWith('0858')) {
      provider = "Indosat Ooredoo";
      name = "Siti Aminah";
    } else if (num.startsWith('0877') || num.startsWith('0878')) {
      provider = "XL Axiata";
      name = "Andi Wijaya";
    } else if (num.length === 11 || num.length === 12) {
      name = "Rizky Pratama";
      provider = input.serviceType.toUpperCase();
    }

    // Artificial delay for realism
    await new Promise(resolve => setTimeout(resolve, 1500));

    return {
      customerName: name,
      provider: provider,
      isValid: true,
    };
  }
);
