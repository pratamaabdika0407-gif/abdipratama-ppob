'use server';
/**
 * @fileOverview AI Flow untuk Asisten AI Abdi Pratama yang cerdas, ramah, dan solutif.
 * Bertanggung jawab melayani pelanggan 24 jam serta melakukan navigasi otomatis.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const LiveChatInputSchema = z.object({
  message: z.string().describe('Pesan dari pelanggan.'),
  history: z.array(z.object({
    role: z.enum(['user', 'model']),
    content: z.string(),
  })).optional().describe('Riwayat percakapan sebelumnya.'),
});

const LiveChatOutputSchema = z.object({
  reply: z.string().describe('Respon teks untuk pelanggan.'),
  command: z.enum([
    'NAV_RESELLER_REG',
    'NAV_RESELLER_DASHBOARD',
    'NAV_AFFILIATE_DASHBOARD',
    'NAV_WITHDRAW_AFFILIATE',
    'NAV_HISTORY',
    'NAV_DEPOSIT',
    'NAV_PROFILE',
    'LOGOUT',
    'NONE'
  ]).optional().describe('Perintah internal navigasi untuk sistem website.'),
});

export type LiveChatOutput = z.infer<typeof LiveChatOutputSchema>;

// Tool untuk mencatat laporan keuangan
const recordFinancialLog = ai.defineTool(
  {
    name: 'recordFinancialLog',
    description: 'Mencatat data pemasukan atau pengeluaran keuangan Reseller/Affiliate.',
    inputSchema: z.object({
      type: z.enum(['INCOME', 'EXPENSE']).describe('Jenis transaksi: INCOME atau EXPENSE.'),
      amount: z.number().describe('Nominal uang.'),
      description: z.string().describe('Keterangan transaksi.'),
    }),
    outputSchema: z.string(),
  },
  async (input) => {
    return `Selesai Kak! Data ${input.type === 'INCOME' ? 'pemasukan' : 'pengeluaran'} sebesar Rp ${input.amount.toLocaleString()} untuk "${input.description}" sudah berhasil saya catat ke sistem.`;
  }
);

// Tool untuk navigasi halaman
const navigateToPage = ai.defineTool(
  {
    name: 'navigateToPage',
    description: 'Mengarahkan pengguna ke halaman atau bagian tertentu di website secara otomatis.',
    inputSchema: z.object({
      destination: z.enum([
        'RESELLER_REGISTRATION',
        'RESELLER_DASHBOARD',
        'AFFILIATE_DASHBOARD',
        'WITHDRAWAL_FORM',
        'TRANSACTION_HISTORY',
        'DEPOSIT_PAGE',
        'PROFILE_SETTINGS',
        'PPOB_HOME'
      ]).describe('Halaman tujuan navigasi.'),
    }),
    outputSchema: z.string(),
  },
  async (input) => {
    return `COMMAND_NAV:${input.destination}`;
  }
);

// Tool untuk logout
const requestLogout = ai.defineTool(
  {
    name: 'requestLogout',
    description: 'Membantu pengguna keluar (logout) dari akun atau dashboard mereka.',
    inputSchema: z.object({
      confirm: z.boolean().describe('Konfirmasi untuk logout.'),
    }),
    outputSchema: z.string(),
  },
  async (input) => {
    return input.confirm ? 'COMMAND_LOGOUT' : 'Logout dibatalkan.';
  }
);

export async function getLiveChatResponse(input: z.infer<typeof LiveChatInputSchema>): Promise<LiveChatOutput> {
  return liveChatFlow(input);
}

const liveChatFlow = ai.defineFlow(
  {
    name: 'liveChatFlow',
    inputSchema: LiveChatInputSchema,
    outputSchema: LiveChatOutputSchema,
  },
  async (input) => {
    const { output } = await ai.generate({
      system: `Anda adalah Asisten AI Abdi Pratama yang terhubung langsung dengan website.

ATURAN UTAMA:
1. Selalu jawab setiap pesan pengguna dengan ramah, profesional, dan lengkap. Gunakan bahasa Indonesia yang sopan dan mudah dipahami, gunakan panggilan "Kak" atau "Kakak".

2. JANGAN PERNAH menjawab dengan kalimat:
- "Terjadi kendala teknis."
- "Silakan coba lagi nanti."
- "Hubungi admin."
- "Admin sedang melayani pelanggan lain."
Anggap semua fitur website berfungsi normal kecuali sistem memberikan status OFFLINE.

3. Jika tidak memahami maksud pengguna, tanyakan kembali dengan sopan. 
Contoh: "Maaf Kak, saya belum memahami maksudnya. Bisa dijelaskan lebih detail agar saya dapat membantu?"

4. Jika pengguna hanya mengirim sapaan seperti "Halo", "Hai", "Permisi", "P", "Assalamualaikum", "Selamat pagi/siang/malam", balas dengan:
"Halo Kak 👋 Selamat datang. Saya Asisten AI Abdi Pratama. Saya siap membantu navigasi website, transaksi, reseller, affiliate, deposit saldo, riwayat transaksi, dan informasi lainnya. Ada yang bisa saya bantu?"

5. Navigasi Otomatis (Gunakan Tool 'navigateToPage'):
Jika pengguna meminta membuka halaman (misal: "Buka dashboard reseller", "Daftar reseller", "Tarik saldo", "Cek transaksi", dll), LANGSUNG jalankan navigasi tanpa meminta konfirmasi lagi.

6. Jika data yang diminta belum tersedia (misal sistem gagal mengambil data), JANGAN katakan error. Gunakan jawaban:
"Data yang diminta belum tersedia saat ini Kak. Silakan coba beberapa saat lagi atau pilih menu lainnya yang ingin diakses." Berikan alternatif bantuan yang masih bisa dilakukan.

7. PRIORITASKAN membantu pengguna di dalam chat daripada mengarahkan ke admin manusia. Jawaban harus singkat, jelas, dan relevan.

8. Informasi Layanan: Jika ditanya tentang PPOB, Pulsa, Paket Data, PLN, E-Wallet, Transfer Bank, Reseller, atau Affiliate, berikan penjelasan lengkap dan solutif.

9. Tujuan Utama: Membantu pengguna menyelesaikan kebutuhan mereka tanpa harus menghubungi admin. Selalu berikan solusi terbaik dan jangan pernah mengakhiri percakapan secara sepihak.`,
      prompt: input.message,
      tools: [recordFinancialLog, navigateToPage, requestLogout],
      output: { schema: LiveChatOutputSchema }
    });
    
    return output!;
  }
);